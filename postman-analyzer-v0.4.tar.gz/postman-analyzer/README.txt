POSTMAN ANALYZER - v0.4
=======================

Herramienta para la recolección y análisis de evidencia asociada
a alertas de exposición pública en Postman.

La herramienta automatiza la preparación del entorno, validación de
sesión mediante navegador, recolección de evidencia y generación de
un análisis técnico sintetizado.


1. REQUISITOS
-------------

- Sistema Linux (probado en Kali Linux).
- Python 3.
- Conexión a Internet durante la primera ejecución.
- Uno de los siguientes navegadores compatibles instalado:

  - Brave
  - Google Chrome
  - Chromium
  - Microsoft Edge

- Acceso válido a Postman.


2. TIPOS DE ALERTA SOPORTADOS
-----------------------------

La herramienta admite actualmente URLs de Postman asociadas a:

- Request
- Collection

Ejemplos:

Request:

  https://go.postman.co/request/XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX

Collection:

  https://postman.com/<perfil>/workspace/<workspace>/collection/<UID>


3. DESEMPAQUETAR
----------------

Ubicarse en la carpeta donde se descargó el archivo:

  cd <CARPETA>

Descomprimir:

  tar -xzf postman-analyzer-v0.4.tar.gz

Ingresar a la herramienta:

  cd postman-analyzer


4. EJECUTAR
-----------

Ejecutar proporcionando la URL de la alerta de Postman:

  ./run_postman.sh 'URL_DE_LA_ALERTA'

Ejemplo:

  ./run_postman.sh 'https://go.postman.co/request/XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX'


5. PRIMERA EJECUCIÓN
--------------------

En la primera ejecución, la herramienta automáticamente:

- Crea un entorno virtual de Python.
- Instala Playwright.
- Detecta un navegador compatible.
- Crea un perfil de navegador exclusivo para el análisis.
- Abre Postman para preparar la sesión.

Durante la primera configuración, la herramienta detiene el proceso
para permitir completar manualmente el acceso a Postman.

En la ventana del navegador:

1. Iniciar sesión en Postman.
2. Completar cualquier CAPTCHA o validación solicitada.
3. Seleccionar la cuenta correspondiente si Postman lo solicita.
4. Esperar hasta visualizar correctamente la interfaz de Postman.
5. Regresar a la terminal y presionar ENTER.

La recolección no comenzará hasta completar este paso.

La herramienta no almacena el usuario ni la contraseña de Postman
dentro de los scripts.


6. EJECUCIONES POSTERIORES
--------------------------

La herramienta reutiliza:

- El entorno virtual.
- Playwright instalado.
- El perfil exclusivo del navegador.
- La sesión de Postman mientras continúe vigente.

Si la sesión continúa disponible, el proceso puede continuar
automáticamente sin solicitar nuevamente el inicio de sesión.

Si Postman requiere autenticación o selección de cuenta, la herramienta
solicitará completar el acceso antes de continuar.


7. ALCANCE DEL ANÁLISIS
-----------------------

La herramienta obtiene contexto general del workspace asociado a la
alerta y profundiza técnicamente en la colección directamente
relacionada con el recurso alertado.

Si la alerta corresponde a una Request:

- Identifica el workspace.
- Identifica la colección a la que pertenece la request.
- Obtiene contexto general del workspace.
- Recopila y analiza en detalle todas las requests de la colección
  asociada.

Si la alerta corresponde a una Collection:

- Identifica el workspace.
- Obtiene contexto general del workspace.
- Recopila y analiza en detalle la colección alertada y sus requests.

El contexto general del workspace puede incluir colecciones, cantidad
de requests, metadata e identidades observadas.

La herramienta no descarga necesariamente en profundidad todas las
requests de todas las colecciones del workspace.


8. RESULTADOS
-------------

Cada ejecución crea automáticamente una carpeta independiente dentro de:

  cases/

El identificador del caso utiliza fecha y hora de Lima, Perú (UTC-5).

Ejemplo:

  cases/20260828_165748_12995041_ff5f7c68/

Dentro de cada caso se generan:

  case_info.json
  raw_workspace.json
  raw_identity.json
  collection_dump.json
  analysis.txt

Al finalizar correctamente, la herramienta intenta abrir
automáticamente:

  analysis.txt

utilizando la aplicación de texto predeterminada del sistema.

Si no fuera posible abrirlo automáticamente, la ruta permanece visible
en la terminal.


9. DESCRIPCIÓN DE LOS ARCHIVOS
------------------------------

case_info.json

  Información general del caso, alcance y estado de ejecución.

raw_workspace.json

  Evidencia relacionada con el workspace, colecciones, alcance,
  metadata y contexto obtenido durante la recolección.

raw_identity.json

  Evidencia relacionada con identidades, perfiles y elementos
  utilizados para la atribución.

collection_dump.json

  Evidencia técnica detallada de la colección analizada y sus
  requests.

  Puede incluir endpoints, headers, parámetros, bodies, variables,
  autenticación y otros valores obtenidos desde Postman.

  Este archivo puede contener valores sin ofuscar.

analysis.txt

  Resultado técnico sintetizado del análisis.

  Incluye, cuando se encuentran disponibles:

  - Tipo de recurso alertado.
  - Workspace y visibilidad.
  - Colección y/o request alertada.
  - Fechas de creación y actualización del recurso.
  - Creación y última actividad del workspace.
  - Información de atribución.
  - Alcance identificado.
  - Dominios y entornos observados.
  - Endpoints analizados.
  - Información técnica relevante.
  - Credenciales, secretos o referencias identificadas.
  - Variables y autenticación de nivel colección.
  - Criticidad estimada global.


10. CRITICIDAD ESTIMADA
-----------------------

El análisis utiliza la siguiente escala global:

  CRÍTICA
  ALTA
  MEDIA
  BAJA

La criticidad se determina a partir de las evidencias identificadas
durante el análisis.

Una referencia a una variable o a Postman Vault no implica por sí sola
que el valor real del secreto se encuentre públicamente expuesto.

La identificación de un valor de autenticación tampoco confirma por sí
sola que continúe vigente o permita acceso.

La herramienta no ejecuta los endpoints ni valida las credenciales
contra los servicios identificados.


11. FECHAS
----------

Las fechas disponibles son obtenidas desde la metadata registrada por
Postman y convertidas a la zona horaria de Lima, Perú (UTC-5).

Dependiendo del tipo de alerta, el reporte puede mostrar:

- Creación de la request.
- Última actualización de la request.
- Creación de la colección.
- Última actualización de la colección.
- Creación del workspace.
- Última actividad registrada en el workspace.

Estas fechas no representan necesariamente la fecha exacta en que el
contenido pasó a estar públicamente disponible.


12. INFORMACIÓN SENSIBLE
------------------------

Los archivos JSON generados deben considerarse evidencia técnica
potencialmente sensible.

No compartir ni publicar:

  browser-profile/
  cases/
  browser.log

El directorio:

  browser-profile/

puede contener información relacionada con la sesión autenticada del
navegador.

El directorio:

  cases/

puede contener endpoints, metadata, identificadores, credenciales,
tokens, API keys u otros valores obtenidos durante la recolección.

El archivo analysis.txt ofusca parcialmente los valores potencialmente
sensibles cuando corresponde.


13. ERRORES
-----------

Si una recolección falla después de crear un caso, la herramienta
conserva la evidencia parcial disponible.

El archivo:

  case_info.json

puede indicar:

  status: failed
  error_stage: <etapa>
  error_message: <detalle>

Esto permite identificar en qué punto ocurrió el problema.

Una recolección incompleta no debe considerarse equivalente a un
análisis completado correctamente.


14. ARCHIVOS GENERADOS LOCALMENTE
---------------------------------

Durante el uso de la herramienta pueden generarse automáticamente:

  .venv/
  browser-profile/
  browser.log
  cases/

Estos elementos no deben incluirse al redistribuir la herramienta.

Para distribución son necesarios únicamente:

  README.txt
  run_postman.sh
  check_session.py
  collect.py
  analyze.py


15. USO RESUMIDO
----------------

Descomprimir:

  tar -xzf postman-analyzer-v0.4.tar.gz

Entrar:

  cd postman-analyzer

Ejecutar:

  ./run_postman.sh 'URL_DE_LA_ALERTA'

En la primera ejecución:

  Completar el acceso a Postman en el navegador y presionar ENTER
  únicamente cuando la interfaz esté completamente disponible.

Resultados:

  cases/<CASE_ID>/

Reporte principal:

  cases/<CASE_ID>/analysis.txt
