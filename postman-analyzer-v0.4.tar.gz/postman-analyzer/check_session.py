import re
import sys

from playwright.sync_api import sync_playwright


CDP_URL = "http://127.0.0.1:9222"


# ============================================================
# ENTRADA
# ============================================================

if len(sys.argv) != 2:
    print("ERROR:URL_REQUIRED")
    raise SystemExit(2)


ALERT_URL = sys.argv[1].strip()


# ============================================================
# DETECTAR TIPO DE ALERTA
# ============================================================

def detect_alert(url):

    request_match = re.search(
        r"/request/([A-Za-z0-9-]+)",
        url
    )

    if request_match:
        return {
            "type": "request",
            "uid": request_match.group(1)
        }

    collection_match = re.search(
        r"/collection/([A-Za-z0-9-]+)",
        url
    )

    if collection_match:
        return {
            "type": "collection",
            "uid": collection_match.group(1)
        }

    return None


alert = detect_alert(
    ALERT_URL
)


if not alert:
    print("ERROR:UNSUPPORTED_URL")
    raise SystemExit(2)


ALERT_TYPE = alert["type"]
RESOURCE_UID = alert["uid"]


# ============================================================
# ENDPOINT DE VALIDACION
# ============================================================

if ALERT_TYPE == "request":

    VALIDATION_URL = (
        "https://www.postman.com/_api/request/"
        f"{RESOURCE_UID}?populate=parent"
    )

elif ALERT_TYPE == "collection":

    # IMPORTANTE:
    # Para las colecciones Postman requiere el UID público
    # completo:
    #
    # ownerId-collectionUUID
    #
    # Ejemplo:
    # 5447545-61f03a58-bb5d-4df6-b4dc-9e7439e7ddf3

    VALIDATION_URL = (
        "https://www.postman.com/_api/collection/"
        f"{RESOURCE_UID}"
    )

else:

    print("ERROR:UNSUPPORTED_TYPE")
    raise SystemExit(2)


# ============================================================
# VALIDAR MEDIANTE LA SESION DEL NAVEGADOR
# ============================================================

try:

    with sync_playwright() as p:

        browser = p.chromium.connect_over_cdp(
            CDP_URL
        )

        if not browser.contexts:
            print("ERROR:NO_CONTEXT")
            raise SystemExit(3)

        context = browser.contexts[0]

        # ----------------------------------------------------
        # SELECCIONAR UN CONTEXTO POSTMAN UTILIZABLE
        # ----------------------------------------------------

        page = None
        page_created = False

        for candidate in context.pages:

            if candidate.url.startswith(
                "https://www.postman.com"
            ):

                page = candidate
                break

        if page is None:

            page = context.new_page()
            page_created = True

            try:

                page.goto(
                    "https://www.postman.com/",
                    wait_until="domcontentloaded",
                    timeout=60000
                )

                page.wait_for_timeout(
                    2000
                )

            except Exception:
                pass

        current_url = (
            page.url
            or ""
        )

        # Si Postman nos llevó al selector/login,
        # existe sesión parcial pero todavía falta
        # resolver la cuenta activa.
        if (
            "identity.getpostman.com"
            in current_url
        ):

            print(
                "SESSION_ACCOUNT_SELECTION_REQUIRED"
            )

            raise SystemExit(1)

        if not current_url.startswith(
            "https://www.postman.com"
        ):

            print(
                "SESSION_UNVERIFIED:"
                f"{ALERT_TYPE}:0"
            )

            raise SystemExit(1)

        result = page.evaluate(
            """async (url) => {

                try {

                    const response = await fetch(
                        url,
                        {
                            method: "GET",
                            credentials: "include"
                        }
                    );

                    return {
                        status: response.status,
                        contentType:
                            response.headers.get(
                                "content-type"
                            ) || "",
                        text:
                            await response.text()
                    };

                } catch (error) {

                    return {
                        status: 0,
                        contentType: "",
                        text: String(error)
                    };
                }

            }""",
            VALIDATION_URL
        )

        status = result.get(
            "status",
            0
        )

        content_type = (
            result.get(
                "contentType",
                ""
            )
            or ""
        ).lower()

        text = (
            result.get(
                "text",
                ""
            )
            or ""
        )

        # ----------------------------------------------------
        # ACCESO CORRECTO
        # ----------------------------------------------------

        if (
            status == 200
            and "json" in content_type
        ):

            print(
                f"SESSION_OK:{ALERT_TYPE}"
            )

            raise SystemExit(0)

        # ----------------------------------------------------
        # SESION NO AUTENTICADA / SIN ACCESO
        # ----------------------------------------------------

        if status in (
            401,
            403
        ):

            print(
                f"SESSION_REQUIRED:{ALERT_TYPE}:{status}"
            )

            raise SystemExit(1)

        lower_text = text.lower()

        if (
            "sign in" in lower_text
            or "login" in lower_text
            or "<!doctype html" in lower_text
        ):

            print(
                f"SESSION_REQUIRED:{ALERT_TYPE}:{status}"
            )

            raise SystemExit(1)

        # ----------------------------------------------------
        # OTRO RESULTADO
        # ----------------------------------------------------

        print(
            f"SESSION_UNVERIFIED:"
            f"{ALERT_TYPE}:"
            f"{status}"
        )

        raise SystemExit(1)


except SystemExit:
    raise


except Exception as exc:

    print(
        "ERROR:"
        + str(exc).replace(
            "\n",
            " "
        )[:300]
    )

    raise SystemExit(3)
