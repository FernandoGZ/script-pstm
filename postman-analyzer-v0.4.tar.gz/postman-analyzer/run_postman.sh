#!/usr/bin/env bash

set -u
set -o pipefail

# ============================================================
# CONFIGURACION
# ============================================================

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

VENV_DIR="$BASE_DIR/.venv"
CASES_DIR="$BASE_DIR/cases"
PROFILE_DIR="$BASE_DIR/browser-profile"

COLLECT_SCRIPT="$BASE_DIR/collect.py"
ANALYZE_SCRIPT="$BASE_DIR/analyze.py"
SESSION_CHECK_SCRIPT="$BASE_DIR/check_session.py"

CDP_HOST="127.0.0.1"
CDP_PORT="9222"
CDP_URL="http://${CDP_HOST}:${CDP_PORT}"

BROWSER_LOG="$BASE_DIR/browser.log"

# Se crea únicamente después de completar correctamente
# la preparación inicial de la sesión de Postman.
PROFILE_READY_MARKER="$PROFILE_DIR/.postman-analyzer-ready"

TEMP_FILES=()

# ============================================================
# COLORES / MENSAJES
# ============================================================

if [ -t 1 ]; then
    GREEN="\033[0;32m"
    YELLOW="\033[1;33m"
    RED="\033[0;31m"
    BLUE="\033[0;34m"
    NC="\033[0m"
else
    GREEN=""
    YELLOW=""
    RED=""
    BLUE=""
    NC=""
fi

info() {
    echo -e "${BLUE}[+]${NC} $1"
}

ok() {
    echo -e "${GREEN}[+]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[!]${NC} $1"
}

fail() {
    echo -e "${RED}[-]${NC} $1" >&2
}

# ============================================================
# LIMPIEZA
# ============================================================

cleanup() {
    for file in "${TEMP_FILES[@]:-}"; do
        [ -n "$file" ] && rm -f "$file"
    done
}

trap cleanup EXIT
trap 'fail "Proceso interrumpido por el usuario."; exit 130' INT TERM

# ============================================================
# AYUDA
# ============================================================

usage() {
    echo
    echo "Uso:"
    echo "  ./run_postman.sh 'URL_ALERTA_POSTMAN'"
    echo
    echo "Ejemplo:"
    echo "  ./run_postman.sh 'https://go.postman.co/request/12345678-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'"
    echo
}

# ============================================================
# VALIDAR ARGUMENTOS
# ============================================================

if [ "$#" -ne 1 ]; then
    usage
    exit 2
fi

ALERT_URL="$1"

# ============================================================
# DETECTAR TIPO DE ALERTA
# ============================================================

ALERT_TYPE=""

if printf '%s' "$ALERT_URL" \
    | grep -Eq '^https://(www\.)?go\.postman\.co/request/[A-Za-z0-9-]+/?$'
then
    ALERT_TYPE="request"

elif printf '%s' "$ALERT_URL" \
    | grep -Eq '^https://(www\.)?postman\.com/[^/]+/workspace/[^/]+/collection/[A-Za-z0-9-]+/?$'
then
    ALERT_TYPE="collection"

elif printf '%s' "$ALERT_URL" \
    | grep -Eq '^https://(www\.)?postman\.com/.*/request/[A-Za-z0-9-]+'
then
    ALERT_TYPE="request"

else
    fail "La URL de Postman no corresponde a un formato soportado."

    echo
    echo "Formatos soportados actualmente:"
    echo
    echo "  Request:"
    echo "    https://go.postman.co/request/<UID>"
    echo
    echo "  Collection:"
    echo "    https://postman.com/<perfil>/workspace/<workspace>/collection/<UID>"
    echo

    exit 2
fi

ok "Tipo de alerta detectado: $ALERT_TYPE"

# ============================================================
# VALIDAR ARCHIVOS BASE
# ============================================================

for required_file in \
    "$COLLECT_SCRIPT" \
    "$ANALYZE_SCRIPT" \
    "$SESSION_CHECK_SCRIPT"
do
    if [ ! -f "$required_file" ]; then
        fail "Falta un archivo requerido:"
        echo "  $required_file" >&2
        exit 3
    fi
done

mkdir -p "$CASES_DIR" "$PROFILE_DIR"

# ============================================================
# VALIDAR HERRAMIENTAS DEL SISTEMA
# ============================================================

for cmd in curl find sort comm sed wc grep tail tr; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
        fail "Falta una dependencia del sistema: $cmd"
        exit 4
    fi
done

# ============================================================
# PYTHON
# ============================================================

if command -v python3 >/dev/null 2>&1; then
    SYSTEM_PYTHON="$(command -v python3)"
else
    fail "Python 3 no está instalado."
    exit 5
fi

PYTHON_VERSION="$(
    "$SYSTEM_PYTHON" -c \
    'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")' \
    2>/dev/null
)"

ok "Python detectado: $SYSTEM_PYTHON ($PYTHON_VERSION)"

# ============================================================
# ENTORNO VIRTUAL
# ============================================================

if [ ! -d "$VENV_DIR" ]; then

    info "Primera ejecución: creando entorno virtual..."

    if ! "$SYSTEM_PYTHON" -m venv "$VENV_DIR"; then
        fail "No se pudo crear el entorno virtual."
        echo
        echo "En Debian/Kali puede ser necesario instalar:"
        echo "  sudo apt install python3-venv"
        exit 6
    fi

    ok "Entorno virtual creado."
fi

if [ ! -f "$VENV_DIR/bin/activate" ]; then
    fail "El entorno virtual existe pero está incompleto."
    exit 6
fi

# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

# ============================================================
# PLAYWRIGHT
# ============================================================

if ! python -c "import playwright" >/dev/null 2>&1; then

    info "Instalando Playwright por primera vez..."

    if ! python -m pip install playwright; then
        fail "No se pudo instalar Playwright."
        exit 7
    fi

    ok "Playwright instalado."

else

    PLAYWRIGHT_VERSION="$(
        python - <<'PY'
import importlib.metadata

try:
    print(importlib.metadata.version("playwright"))
except Exception:
    print("desconocida")
PY
    )"

    ok "Playwright disponible: $PLAYWRIGHT_VERSION"
fi

# ============================================================
# DETECTAR NAVEGADOR
# ============================================================

BROWSER=""
BROWSER_NAME=""

detect_browser() {

    if command -v brave-browser >/dev/null 2>&1; then
        BROWSER="$(command -v brave-browser)"
        BROWSER_NAME="Brave"

    elif command -v google-chrome >/dev/null 2>&1; then
        BROWSER="$(command -v google-chrome)"
        BROWSER_NAME="Google Chrome"

    elif command -v google-chrome-stable >/dev/null 2>&1; then
        BROWSER="$(command -v google-chrome-stable)"
        BROWSER_NAME="Google Chrome"

    elif command -v chromium >/dev/null 2>&1; then
        BROWSER="$(command -v chromium)"
        BROWSER_NAME="Chromium"

    elif command -v chromium-browser >/dev/null 2>&1; then
        BROWSER="$(command -v chromium-browser)"
        BROWSER_NAME="Chromium"

    elif command -v microsoft-edge >/dev/null 2>&1; then
        BROWSER="$(command -v microsoft-edge)"
        BROWSER_NAME="Microsoft Edge"

    elif command -v microsoft-edge-stable >/dev/null 2>&1; then
        BROWSER="$(command -v microsoft-edge-stable)"
        BROWSER_NAME="Microsoft Edge"

    else
        return 1
    fi
}

if ! detect_browser; then
    fail "No se encontró un navegador compatible."

    echo
    echo "Navegadores soportados:"
    echo "  - Brave"
    echo "  - Google Chrome"
    echo "  - Chromium"
    echo "  - Microsoft Edge"

    exit 8
fi

ok "Navegador detectado: $BROWSER_NAME"
info "Ejecutable: $BROWSER"

# ============================================================
# VALIDAR / INICIAR CDP
# ============================================================

cdp_available() {
    curl \
        --silent \
        --show-error \
        --max-time 2 \
        "$CDP_URL/json/version" \
        >/dev/null 2>&1
}

if cdp_available; then

    ok "Sesión de navegador compatible ya disponible en puerto $CDP_PORT."

else

    info "Iniciando navegador con perfil exclusivo de análisis..."

    : > "$BROWSER_LOG"

    "$BROWSER" \
        --remote-debugging-address="$CDP_HOST" \
        --remote-debugging-port="$CDP_PORT" \
        --user-data-dir="$PROFILE_DIR" \
        "https://www.postman.com/" \
        >>"$BROWSER_LOG" 2>&1 &

    BROWSER_PID=$!

    info "Esperando al navegador..."

    READY=0

    for _ in $(seq 1 30); do

        if cdp_available; then
            READY=1
            break
        fi

        if ! kill -0 "$BROWSER_PID" >/dev/null 2>&1; then
            fail "El navegador terminó inesperadamente."

            echo
            echo "Revise:"
            echo "  $BROWSER_LOG"

            exit 9
        fi

        sleep 1
    done

    if [ "$READY" -ne 1 ]; then
        fail "El navegador no respondió en el puerto $CDP_PORT."

        echo
        echo "Revise:"
        echo "  $BROWSER_LOG"

        exit 9
    fi

    ok "Navegador disponible."
fi

# ============================================================
# PREPARACION INICIAL DE POSTMAN
# ============================================================

if [ ! -f "$PROFILE_READY_MARKER" ]; then

    echo
    warn "Primera configuración del perfil de análisis de Postman."

    echo
    echo "Complete el acceso en la ventana del navegador:"
    echo "  1. Inicie sesión en Postman."
    echo "  2. Complete cualquier CAPTCHA o validación solicitada."
    echo "  3. Seleccione la cuenta correspondiente si Postman lo solicita."
    echo "  4. Espere hasta visualizar correctamente la interfaz de Postman."
    echo "  5. Regrese a esta terminal."
    echo

    read -r -p "Presione ENTER únicamente cuando Postman esté completamente listo..."

    echo
fi

# ============================================================
# VALIDAR SESION POSTMAN
# ============================================================

check_postman_session() {

    SESSION_OUTPUT="$(
        python "$SESSION_CHECK_SCRIPT" "$ALERT_URL" 2>&1
    )"

    SESSION_STATUS=$?

    if [ "$SESSION_STATUS" -eq 0 ]; then
        return 0
    fi

    return 1
}

info "Validando sesión de Postman..."

if check_postman_session; then

    ok "Sesión de Postman válida."

else

    if printf '%s' "$SESSION_OUTPUT" | grep -q         '^SESSION_ACCOUNT_SELECTION_REQUIRED'; then

        warn "Postman requiere seleccionar o confirmar una cuenta."

        echo
        echo "En la ventana del navegador:"
        echo "  1. Seleccione la cuenta de Postman que utilizará."
        echo "  2. Espere hasta visualizar la interfaz correctamente."
        echo "  3. Regrese a esta terminal."
        echo

        LOGIN_PROMPT="Presione ENTER cuando haya seleccionado la cuenta..."

    else

        warn "No se detectó una sesión válida de Postman."

        echo
        echo "En la ventana del navegador:"
        echo "  1. Inicie sesión en Postman."
        echo "  2. Espere hasta visualizar la interfaz correctamente."
        echo "  3. Regrese a esta terminal."
        echo

        LOGIN_PROMPT="Presione ENTER cuando haya iniciado sesión..."

    fi

    MAX_LOGIN_ATTEMPTS=3
    LOGIN_ATTEMPT=1

    while [ "$LOGIN_ATTEMPT" -le "$MAX_LOGIN_ATTEMPTS" ]; do

        read -r -p "$LOGIN_PROMPT"

        info "Comprobando sesión..."

        if check_postman_session; then
            ok "Sesión de Postman válida."
            break
        fi

        if printf '%s' "$SESSION_OUTPUT" | grep -q             '^SESSION_ACCOUNT_SELECTION_REQUIRED'; then

            warn "La cuenta de Postman aún no ha sido seleccionada."

            LOGIN_PROMPT="Presione ENTER cuando haya seleccionado la cuenta..."

        else

            warn "La sesión aún no pudo validarse."

            LOGIN_PROMPT="Presione ENTER cuando haya iniciado sesión..."

        fi

        if [ "$LOGIN_ATTEMPT" -eq "$MAX_LOGIN_ATTEMPTS" ]; then

            fail "No fue posible validar una sesión de Postman."

            echo
            echo "Resultado de validación:"
            echo "  $SESSION_OUTPUT"

            echo
            echo "Verifique que:"
            echo "  - haya iniciado sesión correctamente;"
            echo "  - haya seleccionado la cuenta correspondiente;"
            echo "  - Postman haya terminado de cargar;"
            echo "  - la cuenta tenga acceso al recurso alertado."

            exit 10
        fi

        LOGIN_ATTEMPT=$(
            LOGIN_ATTEMPT + 1
        )

    done
fi

# La validación de sesión terminó correctamente.
# Evita repetir la pausa obligatoria en próximas ejecuciones.
touch "$PROFILE_READY_MARKER"

# ============================================================
# SNAPSHOT DE CASES
# ============================================================

BEFORE_FILE="$(mktemp)"
AFTER_FILE="$(mktemp)"

TEMP_FILES+=("$BEFORE_FILE")
TEMP_FILES+=("$AFTER_FILE")

find "$CASES_DIR" \
    -mindepth 1 \
    -maxdepth 1 \
    -type d \
    -printf '%f\n' \
    2>/dev/null \
    | sort \
    > "$BEFORE_FILE"

# ============================================================
# FUNCIONES DE CASES
# ============================================================

detect_new_case() {

    find "$CASES_DIR" \
        -mindepth 1 \
        -maxdepth 1 \
        -type d \
        -printf '%f\n' \
        2>/dev/null \
        | sort \
        > "$AFTER_FILE"

    NEW_CASES="$(
        comm -13 "$BEFORE_FILE" "$AFTER_FILE"
    )"

    NEW_CASE_COUNT="$(
        printf '%s\n' "$NEW_CASES" \
            | sed '/^$/d' \
            | wc -l \
            | tr -d ' '
    )"

    if [ "$NEW_CASE_COUNT" -eq 0 ]; then
        return 1
    fi

    CASE_NAME="$(
        printf '%s\n' "$NEW_CASES" \
            | sed '/^$/d' \
            | tail -n 1
    )"

    CASE_DIR="$CASES_DIR/$CASE_NAME"

    return 0
}


mark_case_failed() {

    local case_dir="$1"
    local message="$2"

    local case_info="$case_dir/case_info.json"

    if [ ! -f "$case_info" ]; then
        return 0
    fi

    python - "$case_info" "$message" <<'PY'
import json
import sys

path = sys.argv[1]
message = sys.argv[2]

try:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
except Exception:
    data = {}

stage = (
    data.get("stage")
    or data.get("error_stage")
    or "unknown"
)

data["status"] = "failed"
data["error_stage"] = stage
data["error_message"] = message

with open(
    path,
    "w",
    encoding="utf-8"
) as f:
    json.dump(
        data,
        f,
        indent=2,
        ensure_ascii=False
    )
PY
}


show_failed_case() {

    local case_dir="$1"

    local case_info="$case_dir/case_info.json"

    local failed_summary=""

    if [ -f "$case_info" ]; then

        failed_summary="$(
            python - "$case_info" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as f:
    d = json.load(f)

print(
    d.get("status")
    or "failed"
)

print(
    d.get("error_stage")
    or d.get("stage")
    or "unknown"
)

print(
    d.get("error_message")
    or "No se registró detalle adicional."
)
PY
        )"
    fi

    FAILED_STATUS="$(
        printf '%s\n' "$failed_summary" \
            | sed -n '1p'
    )"

    FAILED_STAGE="$(
        printf '%s\n' "$failed_summary" \
            | sed -n '2p'
    )"

    FAILED_MESSAGE="$(
        printf '%s\n' "$failed_summary" \
            | sed -n '3p'
    )"

    echo
    echo "============================================================"
    echo "RECOLECCION INCOMPLETA"
    echo "============================================================"
    echo

    echo "Caso:"
    echo "  $(basename "$case_dir")"
    echo

    echo "Estado:"
    echo "  ${FAILED_STATUS:-failed}"
    echo

    echo "Etapa:"
    echo "  ${FAILED_STAGE:-unknown}"
    echo

    echo "Detalle:"
    echo "  ${FAILED_MESSAGE:-No disponible}"
    echo

    echo "Evidencia parcial conservada en:"
    echo "  $case_dir"
    echo
}

# ============================================================
# RECOLECCION
# ============================================================

echo
echo "============================================================"
echo "RECOLECCION"
echo "============================================================"
echo

python "$COLLECT_SCRIPT" "$ALERT_URL"
COLLECT_STATUS=$?

if [ "$COLLECT_STATUS" -ne 0 ]; then

    if detect_new_case; then

        mark_case_failed \
            "$CASE_DIR" \
            "collect.py terminó con código $COLLECT_STATUS"

        show_failed_case "$CASE_DIR"

    else

        fail "La recolección falló antes de crear un caso."
    fi

    exit 11
fi

# ============================================================
# IDENTIFICAR CASE NUEVO
# ============================================================

if ! detect_new_case; then
    fail "La recolección terminó, pero no se identificó un caso nuevo."
    exit 12
fi

if [ "$NEW_CASE_COUNT" -gt 1 ]; then
    warn "Se detectaron varios casos nuevos; se utilizará el más reciente."
fi

ok "Caso identificado: $CASE_NAME"

# ============================================================
# VALIDAR OUTPUT DEL RECOLECTOR
# ============================================================

REQUIRED_RAW_FILES=(
    "case_info.json"
    "raw_workspace.json"
    "raw_identity.json"
    "collection_dump.json"
)

for required in "${REQUIRED_RAW_FILES[@]}"; do

    if [ ! -s "$CASE_DIR/$required" ]; then

        mark_case_failed \
            "$CASE_DIR" \
            "Falta o está vacío el archivo requerido: $required"

        show_failed_case "$CASE_DIR"

        exit 13
    fi
done

# ============================================================
# VALIDAR ESTADO COMPLETED
# ============================================================

CASE_STATUS="$(
    python - "$CASE_DIR/case_info.json" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as f:
    d = json.load(f)

print(
    d.get("status")
    or "unknown"
)
PY
)"

if [ "$CASE_STATUS" != "completed" ]; then

    mark_case_failed \
        "$CASE_DIR" \
        "El recolector terminó sin dejar el caso en estado completed."

    show_failed_case "$CASE_DIR"

    exit 13
fi

ok "Evidencia cruda generada correctamente."

# ============================================================
# ANALISIS
# ============================================================

echo
echo "============================================================"
echo "ANALISIS"
echo "============================================================"
echo

python "$ANALYZE_SCRIPT" "$CASE_DIR"
ANALYZE_STATUS=$?

if [ "$ANALYZE_STATUS" -ne 0 ]; then

    mark_case_failed \
        "$CASE_DIR" \
        "analyze.py terminó con código $ANALYZE_STATUS"

    fail "La recolección fue completada, pero el análisis falló."

    echo
    echo "La evidencia cruda se conserva en:"
    echo "  $CASE_DIR"
    echo

    exit 14
fi

ANALYSIS_FILE="$CASE_DIR/analysis.txt"

if [ ! -s "$ANALYSIS_FILE" ]; then

    mark_case_failed \
        "$CASE_DIR" \
        "analysis.txt no fue generado correctamente."

    fail "El análisis no generó analysis.txt."

    echo
    echo "La evidencia cruda se conserva en:"
    echo "  $CASE_DIR"
    echo

    exit 15
fi

# ============================================================
# LEER CASE INFO
# ============================================================

CASE_INFO="$CASE_DIR/case_info.json"

SUMMARY="$(
python - "$CASE_INFO" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as f:
    d = json.load(f)

scope = d.get("scope", {})

print(d.get("workspace_name") or "No identificado")
print(scope.get("workspace_collections", "?"))
print(scope.get("workspace_requests", "?"))
print(scope.get("alerted_collection_requests", "?"))
PY
)"

WORKSPACE_NAME="$(
    printf '%s\n' "$SUMMARY" \
        | sed -n '1p'
)"

WORKSPACE_COLLECTIONS="$(
    printf '%s\n' "$SUMMARY" \
        | sed -n '2p'
)"

WORKSPACE_REQUESTS="$(
    printf '%s\n' "$SUMMARY" \
        | sed -n '3p'
)"

ALERTED_REQUESTS="$(
    printf '%s\n' "$SUMMARY" \
        | sed -n '4p'
)"

# ============================================================
# RESUMEN FINAL
# ============================================================

echo
echo "============================================================"
echo "ANALISIS FINALIZADO"
echo "============================================================"
echo

echo "Caso:"
echo "  $CASE_NAME"
echo

echo "Workspace:"
echo "  $WORKSPACE_NAME"
echo

echo "Alcance:"
echo "  $WORKSPACE_COLLECTIONS colecciones"
echo "  $WORKSPACE_REQUESTS requests en el workspace"
echo "  $ALERTED_REQUESTS requests analizadas en detalle"
echo

echo "Reporte técnico:"
echo "  $ANALYSIS_FILE"
echo

echo "Evidencia cruda:"
echo "  $CASE_DIR"
echo

echo "Archivos generados:"
echo "  - case_info.json"
echo "  - raw_workspace.json"
echo "  - raw_identity.json"
echo "  - collection_dump.json"
echo "  - analysis.txt"
echo

ok "Proceso completado correctamente."

# ============================================================
# ABRIR REPORTE AUTOMATICAMENTE
# ============================================================

if [ -f "$ANALYSIS_FILE" ]; then

    if command -v xdg-open >/dev/null 2>&1; then

        info "Abriendo reporte técnico..."

        xdg-open "$ANALYSIS_FILE"             >/dev/null 2>&1 &

    else

        warn "No se encontró xdg-open."
        echo "Abra manualmente:"
        echo "  $ANALYSIS_FILE"

    fi

fi
