from playwright.sync_api import sync_playwright
from urllib.parse import urlparse, parse_qs
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo
from pathlib import Path
import json
import time
import sys
import re
import traceback


# ============================================================
# CONFIGURACION
# ============================================================

CDP_URL = "http://127.0.0.1:9222"

BASE_CASES_DIR = Path("cases")

EMAIL_RE = re.compile(
    r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"
)


# ============================================================
# ENTRADA
# ============================================================

if len(sys.argv) != 2:
    print("Uso:")
    print("  python collect.py <URL_ALERTA_POSTMAN>")
    raise SystemExit(1)

ALERT_URL = sys.argv[1].strip()

# ============================================================
# DETECTAR TIPO DE ALERTA
# ============================================================

REQUEST_UID = None
COLLECTION_UID = None
ALERT_TYPE = None

request_match = re.search(
    r"/request/([A-Za-z0-9-]+)",
    ALERT_URL
)

collection_match = re.search(
    r"/collection/([A-Za-z0-9-]+)",
    ALERT_URL
)

if request_match:

    ALERT_TYPE = "request"
    REQUEST_UID = request_match.group(1)
    RESOURCE_UID = REQUEST_UID

elif collection_match:

    ALERT_TYPE = "collection"
    COLLECTION_UID = collection_match.group(1)
    RESOURCE_UID = COLLECTION_UID

else:

    print(
        "[-] No se pudo identificar un recurso "
        "Request o Collection en la URL."
    )

    raise SystemExit(1)


print(
    "[+] Tipo de alerta:",
    ALERT_TYPE
)


# ============================================================
# CREAR CASE ID Y CARPETA
# ============================================================

LIMA_TZ = ZoneInfo("America/Lima")

now = datetime.now(LIMA_TZ)

timestamp_id = now.strftime("%Y%m%d_%H%M%S")

uid_parts = RESOURCE_UID.split("-")

if len(uid_parts) >= 2:
    uid_short = f"{uid_parts[0]}_{uid_parts[1]}"
else:
    uid_short = re.sub(
        r"[^A-Za-z0-9]+",
        "_",
        RESOURCE_UID[:24]
    ).strip("_")

CASE_ID = f"{timestamp_id}_{uid_short}"

CASE_DIR = BASE_CASES_DIR / CASE_ID

CASE_DIR.mkdir(
    parents=True,
    exist_ok=False
)

CASE_INFO_FILE = CASE_DIR / "case_info.json"
RAW_WORKSPACE_FILE = CASE_DIR / "raw_workspace.json"
RAW_IDENTITY_FILE = CASE_DIR / "raw_identity.json"
COLLECTION_DUMP_FILE = CASE_DIR / "collection_dump.json"


print("[+] Case ID:", CASE_ID)
print("[+] Carpeta:", CASE_DIR)
print("[+] URL de alerta:", ALERT_URL)

if ALERT_TYPE == "request":
    print("[+] Request UID:", REQUEST_UID)
else:
    print("[+] Collection UID:", COLLECTION_UID)


# ============================================================
# UTILIDADES
# ============================================================

def normalize_id(value):
    if value is None:
        return None

    if isinstance(value, dict):
        value = value.get("id")

    if value is None:
        return None

    return str(value)


def parse_json(text):
    try:
        return json.loads(text)
    except Exception:
        return None


def extract_emails(obj, path=""):
    results = []

    if isinstance(obj, dict):

        for key, value in obj.items():

            current_path = (
                f"{path}.{key}"
                if path
                else str(key)
            )

            if isinstance(value, (dict, list)):
                results.extend(
                    extract_emails(
                        value,
                        current_path
                    )
                )

            elif isinstance(value, str):

                for email in EMAIL_RE.findall(value):
                    results.append({
                        "email": email,
                        "path": current_path
                    })

    elif isinstance(obj, list):

        for index, value in enumerate(obj):

            current_path = (
                f"{path}[{index}]"
                if path
                else f"[{index}]"
            )

            results.extend(
                extract_emails(
                    value,
                    current_path
                )
            )

    return results


def looks_like_profile(obj):
    if not isinstance(obj, dict):
        return False

    uid = (
        obj.get("id")
        or obj.get("userId")
    )

    if not uid:
        return False

    name = (
        obj.get("name")
        or obj.get("friendly")
    )

    if not name:
        return False

    profile_fields = [
        "username",
        "publicHandle",
        "public_handle",
        "profilePicUrl",
        "profile_pic_url",
        "isPublic",
        "is_public",
        "slug"
    ]

    return any(
        field in obj
        for field in profile_fields
    )


def normalize_profile(obj):
    if not looks_like_profile(obj):
        return None

    return {
        "user_id": str(
            obj.get("id")
            or obj.get("userId")
        ),

        "name": (
            obj.get("name")
            or obj.get("friendly")
        ),

        "username": obj.get("username"),

        "slug": obj.get("slug"),

        "public_handle": (
            obj.get("publicHandle")
            or obj.get("public_handle")
        ),

        "is_public": (
            obj.get("isPublic")
            if "isPublic" in obj
            else obj.get("is_public")
        ),

        "is_accessible": (
            obj.get("isAccessible")
            if "isAccessible" in obj
            else obj.get("is_accessible")
        )
    }


def profile_score(profile):
    score = 0

    for key in [
        "name",
        "username",
        "slug",
        "public_handle"
    ]:
        if profile.get(key):
            score += 1

    if profile.get("is_public") is not None:
        score += 1

    if profile.get("is_accessible") is not None:
        score += 1

    return score


def add_profile(profile_map, obj):
    profile = normalize_profile(obj)

    if not profile:
        return

    uid = profile["user_id"]

    existing = profile_map.get(uid)

    if (
        existing is None
        or profile_score(profile)
        > profile_score(existing)
    ):
        profile_map[uid] = profile


def unique_email_entries(entries):
    seen = set()
    output = []

    for item in entries:

        signature = (
            item.get("email"),
            item.get("source"),
            item.get("path")
        )

        if signature in seen:
            continue

        seen.add(signature)
        output.append(item)

    return output


# ============================================================
# GUARDAR CASE INFO INICIAL
# ============================================================

case_info = {
    "case_id": CASE_ID,
    "collected_at_lima": now.isoformat(timespec="seconds"),
    "alert_url": ALERT_URL,
    "alert_type": ALERT_TYPE,
    "resource_uid": RESOURCE_UID,
    "request_uid": REQUEST_UID,
    "collection_uid": COLLECTION_UID,
    "status": "collecting",
    "stage": "initialization"
}

with open(
    CASE_INFO_FILE,
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        case_info,
        file,
        indent=2,
        ensure_ascii=False
    )



# ============================================================
# ESTADO DEL CASO
# ============================================================

CURRENT_STAGE = "initialization"


def update_case_status(
    status,
    stage=None,
    error_message=None
):
    """
    Actualiza case_info.json sin eliminar los datos ya existentes.
    """

    try:
        if CASE_INFO_FILE.exists():
            with open(
                CASE_INFO_FILE,
                encoding="utf-8"
            ) as file:
                data = json.load(file)
        else:
            data = {
                "case_id": CASE_ID,
                "collected_at_lima": now.isoformat(
                    timespec="seconds"
                ),
                "alert_url": ALERT_URL,
                "alert_type": ALERT_TYPE,
                "resource_uid": RESOURCE_UID,
                "request_uid": REQUEST_UID,
                "collection_uid": COLLECTION_UID
            }

        data["status"] = status

        if stage is not None:
            data["stage"] = stage

        if error_message is not None:
            data["error_stage"] = stage
            data["error_message"] = str(
                error_message
            )[:2000]
        else:
            data.pop(
                "error_stage",
                None
            )
            data.pop(
                "error_message",
                None
            )

        with open(
            CASE_INFO_FILE,
            "w",
            encoding="utf-8"
        ) as file:
            json.dump(
                data,
                file,
                indent=2,
                ensure_ascii=False
            )

    except Exception:
        pass



def fail_case(stage, message, exit_code=1):
    update_case_status(
        "failed",
        stage=stage,
        error_message=message
    )

    print(
        f"[-] Error durante {stage}: {message}"
    )

    raise SystemExit(exit_code)


# ============================================================
# PLAYWRIGHT
# ============================================================

with sync_playwright() as p:

    try:
        browser = p.chromium.connect_over_cdp(
            CDP_URL
        )
    except Exception:
        print(
            "[-] No se pudo conectar a Brave en "
            "http://127.0.0.1:9222"
        )
        raise SystemExit(1)

    if not browser.contexts:
        print("[-] No se encontró contexto de navegador.")
        raise SystemExit(1)

    context = browser.contexts[0]

    if context.pages:
        page = context.pages[0]
    else:
        page = context.new_page()

    workspace_id = None

    workspace_metadata_candidates = []

    profiles_observed = {}

    presence_user_ids = set()

    workspace_user_map_candidates = []

    relationships = defaultdict(set)


    # ========================================================
    # CAPTURA DE RESPUESTAS
    # ========================================================

    def capture_response(response):
        global workspace_id

        try:

            if (
                workspace_id is None
                and "workspace=" in response.url
            ):

                parsed = urlparse(
                    response.url
                )

                params = parse_qs(
                    parsed.query
                )

                if (
                    "workspace" in params
                    and params["workspace"]
                ):

                    candidate = (
                        params["workspace"][0]
                    )

                    if candidate:

                        workspace_id = candidate

                        print(
                            "[+] Workspace ID capturado desde URL:",
                            workspace_id
                        )

            content_type = (
                response.headers.get(
                    "content-type",
                    ""
                )
            )

            if "json" not in content_type.lower():
                return

            try:
                data = response.json()
            except Exception:
                return

            if not isinstance(data, dict):
                return

            meta = data.get(
                "meta",
                {}
            )

            if (
                isinstance(meta, dict)
                and meta.get("model") == "workspace"
                and meta.get("action")
                in ("findOne", "find")
            ):

                ws_data = data.get(
                    "data"
                )

                if isinstance(
                    ws_data,
                    dict
                ):
                    candidates = [
                        ws_data
                    ]

                elif isinstance(
                    ws_data,
                    list
                ):
                    candidates = [
                        item
                        for item in ws_data
                        if isinstance(
                            item,
                            dict
                        )
                    ]

                else:
                    candidates = []

                for candidate in candidates:

                    candidate_id = normalize_id(
                        candidate.get(
                            "id"
                        )
                    )

                    if (
                        candidate_id
                        and workspace_id is None
                    ):

                        workspace_id = (
                            candidate_id
                        )

                        print(
                            "[+] Workspace ID capturado desde ws/proxy:",
                            workspace_id
                        )

                    if candidate_id:

                        workspace_metadata_candidates.append(
                            candidate
                        )

                        created_by = normalize_id(
                            candidate.get(
                                "createdBy"
                            )
                        )

                        updated_by = normalize_id(
                            candidate.get(
                                "updatedBy"
                            )
                        )

                        user = normalize_id(
                            candidate.get(
                                "user"
                            )
                        )

                        if created_by:
                            relationships[
                                created_by
                            ].add(
                                "workspace_createdBy"
                            )

                        if updated_by:
                            relationships[
                                updated_by
                            ].add(
                                "workspace_updatedBy"
                            )

                        if user:
                            relationships[
                                user
                            ].add(
                                "workspace_user"
                            )

                        contributors = (
                            candidate.get(
                                "contributors"
                            )
                            or {}
                        )

                        if isinstance(
                            contributors,
                            dict
                        ):

                            for contributor_type, contributor_list in contributors.items():

                                if not isinstance(
                                    contributor_list,
                                    list
                                ):
                                    continue

                                for contributor in contributor_list:

                                    contributor_id = normalize_id(
                                        contributor
                                    )

                                    if contributor_id:

                                        relationships[
                                            contributor_id
                                        ].add(
                                            "workspace_contributor:"
                                            + str(
                                                contributor_type
                                            )
                                        )

                                    if isinstance(
                                        contributor,
                                        dict
                                    ):
                                        add_profile(
                                            profiles_observed,
                                            contributor
                                        )

                        created_by_obj = (
                            candidate.get(
                                "createdBy"
                            )
                        )

                        if isinstance(
                            created_by_obj,
                            dict
                        ):
                            add_profile(
                                profiles_observed,
                                created_by_obj
                            )

            response_model = data.get(
                "model"
            )

            response_model_id = normalize_id(
                data.get(
                    "modelId"
                )
            )

            users = data.get(
                "users"
            )

            if (
                response_model == "workspace"
                and response_model_id
                and isinstance(
                    users,
                    dict
                )
            ):

                if (
                    workspace_id is None
                    or response_model_id
                    == workspace_id
                ):

                    for uid in users.keys():

                        uid = str(uid)

                        presence_user_ids.add(
                            uid
                        )

                        relationships[
                            uid
                        ].add(
                            "workspace_presence"
                        )

            if (
                set(
                    data.keys()
                )
                == {"users"}
                and isinstance(
                    users,
                    dict
                )
            ):

                candidate_map = {}

                for uid, user_data in users.items():

                    if not isinstance(
                        user_data,
                        dict
                    ):
                        continue

                    profile = normalize_profile(
                        user_data
                    )

                    if profile:
                        candidate_map[
                            str(uid)
                        ] = profile

                if candidate_map:
                    workspace_user_map_candidates.append(
                        candidate_map
                    )

        except Exception:
            pass


    page.on(
        "response",
        capture_response
    )


    # ========================================================
    # ABRIR ALERTA
    # ========================================================

    CURRENT_STAGE = "opening_alert"
    update_case_status("collecting", CURRENT_STAGE)

    print("[+] Abriendo alerta...")

    page.goto(
        ALERT_URL,
        wait_until="domcontentloaded",
        timeout=60000
    )

    print("[+] Esperando carga de Postman...")

    page.wait_for_timeout(
        10000
    )

    if not workspace_id:

        print(
            "[!] Workspace ID no detectado durante la navegación."
        )

        # ====================================================
        # FALLBACK: RESOLVER WORKSPACE MEDIANTE SEARCH API
        # ====================================================

        if ALERT_TYPE == "request":

            print(
                "[+] Intentando resolver workspace "
                "desde la colección asociada..."
            )

            # Reutilizar preferentemente una pestaña existente
            # de www.postman.com. Esto evita abrir nuevamente el
            # selector de cuenta cuando ya existe una sesión válida.
            fallback_page = None
            fallback_page_created = False

            for candidate_page in context.pages:

                if candidate_page.url.startswith(
                    "https://www.postman.com"
                ):

                    fallback_page = candidate_page
                    break

            if fallback_page is None:

                fallback_page = context.new_page()
                fallback_page_created = True

                fallback_page.goto(
                    "https://www.postman.com/",
                    wait_until="domcontentloaded",
                    timeout=60000
                )

                fallback_page.wait_for_timeout(
                    3000
                )

            print(
                "[+] Página Postman utilizada para fallback:",
                fallback_page.url
            )

            try:

                # --------------------------------------------
                # 1. CONSULTAR REQUEST ALERTADA
                # --------------------------------------------

                fallback_request_url = (
                    "https://www.postman.com/_api/request/"
                    f"{REQUEST_UID}?populate=parent"
                )

                fallback_request_result = (
                    fallback_page.evaluate(
                        """async (url) => {

                            try {

                                const response = await fetch(
                                    url,
                                    {
                                        method: "GET",
                                        credentials: "include"
                                    }
                                );

                                return {
                                    status: response.status,
                                    text: await response.text()
                                };

                            } catch (error) {

                                return {
                                    status: 0,
                                    text: String(error)
                                };
                            }

                        }""",
                        fallback_request_url
                    )
                )

                if (
                    fallback_request_result[
                        "status"
                    ]
                    == 200
                ):

                    fallback_request_json = parse_json(
                        fallback_request_result[
                            "text"
                        ]
                    )

                    fallback_request_data = (
                        fallback_request_json.get(
                            "data",
                            {}
                        )
                        if isinstance(
                            fallback_request_json,
                            dict
                        )
                        else {}
                    )

                    fallback_collection = (
                        fallback_request_data.get(
                            "collection"
                        )
                        or {}
                    )

                    fallback_collection_id = (
                        fallback_collection.get(
                            "id"
                        )
                    )

                    fallback_collection_name = (
                        fallback_collection.get(
                            "name"
                        )
                    )

                    fallback_owner = normalize_id(
                        fallback_request_data.get(
                            "owner"
                        )
                    )

                    if (
                        fallback_collection_id
                        and fallback_collection_name
                    ):

                        # Postman Search utiliza el UID completo:
                        # owner + collection id.
                        if fallback_owner:

                            expected_collection_uid = (
                                f"{fallback_owner}-"
                                f"{fallback_collection_id}"
                            )

                        else:

                            expected_collection_uid = (
                                str(
                                    fallback_collection_id
                                )
                            )

                        print(
                            "[+] Colección identificada:",
                            fallback_collection_name
                        )

                        # ------------------------------------
                        # 2. BUSCAR COLECCIÓN EN SEARCH API
                        # ------------------------------------

                        search_payload = {
                            "service": "search",
                            "method": "POST",
                            "path": "/search-all",
                            "body": {
                                "queryIndices": [
                                    "runtime.collection",
                                    "runtime.request",
                                    "collaboration.workspace"
                                ],
                                "queryText":
                                    fallback_collection_name,
                                "size": 25,
                                "from": 0,
                                "requestOrigin":
                                    "workspace-resolution",
                                "mergeEntities": True,
                                "nonNestedRequests": True,
                                "domain": "all",
                                "filter": {}
                            }
                        }

                        search_result = (
                            fallback_page.evaluate(
                                """async (payload) => {

                                    try {

                                        const response = await fetch(
                                            "https://www.postman.com/_api/ws/proxy",
                                            {
                                                method: "POST",
                                                credentials: "include",
                                                headers: {
                                                    "content-type":
                                                        "application/json"
                                                },
                                                body: JSON.stringify(
                                                    payload
                                                )
                                            }
                                        );

                                        return {
                                            status: response.status,
                                            text: await response.text()
                                        };

                                    } catch (error) {

                                        return {
                                            status: 0,
                                            text: String(error)
                                        };
                                    }

                                }""",
                                search_payload
                            )
                        )

                        if (
                            search_result[
                                "status"
                            ]
                            == 200
                        ):

                            search_json = parse_json(
                                search_result[
                                    "text"
                                ]
                            )

                            search_items = []

                            if isinstance(
                                search_json,
                                dict
                            ):

                                search_items = (
                                    search_json.get(
                                        "data"
                                    )
                                    or []
                                )

                            for search_item in (
                                search_items
                            ):

                                if not isinstance(
                                    search_item,
                                    dict
                                ):
                                    continue

                                document = (
                                    search_item.get(
                                        "document"
                                    )
                                    or {}
                                )

                                if not isinstance(
                                    document,
                                    dict
                                ):
                                    continue

                                document_id = str(
                                    document.get(
                                        "id",
                                        ""
                                    )
                                )

                                document_type = str(
                                    document.get(
                                        "entityType",
                                        ""
                                    )
                                ).lower()

                                if (
                                    document_type
                                    != "collection"
                                ):
                                    continue

                                # Coincidencia exacta:
                                # evita seleccionar colecciones
                                # con nombres similares.
                                exact_match = (
                                    document_id
                                    == expected_collection_uid
                                    or document_id.endswith(
                                        "-"
                                        + str(
                                            fallback_collection_id
                                        )
                                    )
                                )

                                if not exact_match:
                                    continue

                                candidate_workspace_id = (
                                    document.get(
                                        "workspaceId"
                                    )
                                )

                                if (
                                    not candidate_workspace_id
                                ):

                                    workspaces = (
                                        document.get(
                                            "workspaces"
                                        )
                                        or []
                                    )

                                    if (
                                        workspaces
                                        and isinstance(
                                            workspaces[0],
                                            dict
                                        )
                                    ):

                                        candidate_workspace_id = (
                                            workspaces[0].get(
                                                "id"
                                            )
                                        )

                                if candidate_workspace_id:

                                    workspace_id = str(
                                        candidate_workspace_id
                                    )

                                    print(
                                        "[+] Workspace ID "
                                        "resuelto mediante "
                                        "Search API:",
                                        workspace_id
                                    )

                                    workspace_metadata_candidates.append({
                                        "id":
                                            workspace_id,

                                        "name":
                                            document.get(
                                                "workspaceName"
                                            ),

                                        "visibilityStatus":
                                            document.get(
                                                "workspaceVisibilityStatus"
                                            ),

                                        "state":
                                            document.get(
                                                "workspaceState"
                                            ),

                                        "profileInfo": {
                                            "slug":
                                                document.get(
                                                    "workspaceSlug"
                                                )
                                        }
                                    })

                                    break

            except Exception as exc:

                print(
                    "[!] Falló fallback de workspace:",
                    str(exc)
                )

            finally:

                # Cerrar solamente una pestaña creada
                # específicamente por este fallback.
                if (
                    fallback_page_created
                    and fallback_page is not None
                ):

                    try:
                        fallback_page.close()
                    except Exception:
                        pass


    if not workspace_id:

        fail_case(
            CURRENT_STAGE,
            "No se pudo descubrir el Workspace ID "
            "mediante navegación ni Search API.",
            1
        )


    print(
        "[+] Workspace ID definitivo:",
        workspace_id
    )


    # ========================================================
    # FUNCIONES AUTENTICADAS
    # ========================================================

    def authenticated_get(url):

        return page.evaluate(
            """async (url) => {

                const response = await fetch(
                    url,
                    {
                        method: "GET",
                        credentials: "include"
                    }
                );

                return {
                    status: response.status,
                    text: await response.text()
                };

            }""",
            url
        )


    def authenticated_post(
        url,
        payload
    ):

        return page.evaluate(
            """async ({url, payload}) => {

                const response = await fetch(
                    url,
                    {
                        method: "POST",
                        credentials: "include",
                        headers: {
                            "content-type":
                                "application/json"
                        },
                        body: JSON.stringify(
                            payload
                        )
                    }
                );

                return {
                    status: response.status,
                    text: await response.text()
                };

            }""",
            {
                "url": url,
                "payload": payload
            }
        )


    # ========================================================
    # RESOLVER RECURSO ALERTADO
    # ========================================================

    request_detail = None
    request_data = {}

    request_name = None

    collection_id = None
    collection_name = None
    collection_detail = None
    collection_detail_data = {}

    # Metadata completa de la colección alertada/asociada.
    # Se conserva para analizar variables, auth y otros
    # atributos de nivel colección.
    alerted_collection_context = {}

    alerted_owner = None
    alerted_updated_by = None


    if ALERT_TYPE == "request":

        CURRENT_STAGE = "alerted_request"
        update_case_status(
            "collecting",
            CURRENT_STAGE
        )

        print()
        print(
            "[+] Consultando request alertada..."
        )

        request_url = (
            "https://www.postman.com/_api/request/"
            f"{REQUEST_UID}?populate=parent"
        )

        request_result = authenticated_get(
            request_url
        )

        print(
            "[+] Request HTTP:",
            request_result["status"]
        )

        if request_result["status"] != 200:

            fail_case(
                CURRENT_STAGE,
                "No se pudo consultar la request alertada. "
                f"HTTP {request_result['status']}",
                1
            )

        request_detail = parse_json(
            request_result["text"]
        )

        if not isinstance(
            request_detail,
            dict
        ):

            fail_case(
                CURRENT_STAGE,
                "La respuesta de la request no contiene JSON válido.",
                1
            )

        request_data = (
            request_detail.get(
                "data"
            )
            or {}
        )

        request_name = request_data.get(
            "name"
        )

        collection_parent = (
            request_data.get(
                "collection"
            )
            or {}
        )

        alerted_collection_context = (
            collection_parent
            if isinstance(collection_parent, dict)
            else {}
        )

        collection_id = collection_parent.get(
            "id"
        )

        collection_name = collection_parent.get(
            "name"
        )

        alerted_owner = normalize_id(
            request_data.get(
                "owner"
            )
        )

        alerted_updated_by = normalize_id(
            request_data.get(
                "lastUpdatedBy"
            )
        )

        if alerted_owner:

            relationships[
                alerted_owner
            ].add(
                "alerted_request_owner"
            )

        if alerted_updated_by:

            relationships[
                alerted_updated_by
            ].add(
                "alerted_request_lastUpdatedBy"
            )

        print(
            "[+] Request:",
            request_name
        )

        print(
            "[+] Collection:",
            collection_name
        )


    elif ALERT_TYPE == "collection":

        CURRENT_STAGE = "alerted_collection"
        update_case_status(
            "collecting",
            CURRENT_STAGE
        )

        print()
        print(
            "[+] Consultando colección alertada..."
        )

        collection_url = (
            "https://www.postman.com/_api/collection/"
            f"{COLLECTION_UID}"
        )

        collection_result = authenticated_get(
            collection_url
        )

        print(
            "[+] Collection HTTP:",
            collection_result["status"]
        )

        if collection_result["status"] != 200:

            fail_case(
                CURRENT_STAGE,
                "No se pudo consultar la colección alertada. "
                f"HTTP {collection_result['status']}",
                1
            )

        collection_detail = parse_json(
            collection_result[
                "text"
            ]
        )

        if not isinstance(
            collection_detail,
            dict
        ):

            fail_case(
                CURRENT_STAGE,
                "La respuesta de la colección no contiene JSON válido.",
                1
            )

        collection_detail_data = (
            collection_detail.get(
                "data"
            )
            or {}
        )

        alerted_collection_context = (
            collection_detail_data
            if isinstance(collection_detail_data, dict)
            else {}
        )

        collection_id = (
            collection_detail_data.get(
                "id"
            )
        )

        collection_name = (
            collection_detail_data.get(
                "name"
            )
        )

        alerted_owner = normalize_id(
            collection_detail_data.get(
                "owner"
            )
        )

        alerted_updated_by = normalize_id(
            collection_detail_data.get(
                "lastUpdatedBy"
            )
        )

        if alerted_owner:

            relationships[
                alerted_owner
            ].add(
                "alerted_collection_owner"
            )

        if alerted_updated_by:

            relationships[
                alerted_updated_by
            ].add(
                "alerted_collection_lastUpdatedBy"
            )

        print(
            "[+] Collection:",
            collection_name
        )

        print(
            "[+] Collection ID:",
            collection_id
        )

        print(
            "[+] Collection owner:",
            alerted_owner
        )


    # ========================================================
    # COLECCIONES ENRIQUECIDAS
    # ========================================================

    CURRENT_STAGE = "workspace_collections"
    update_case_status("collecting", CURRENT_STAGE)

    print()
    print(
        "[+] Consultando colecciones enriquecidas..."
    )

    collections_url = (
        "https://www.postman.com/"
        "_api/list/collection"
        f"?workspace={workspace_id}"
    )

    collections_result = authenticated_post(
        collections_url,
        workspace_id
    )

    print(
        "[+] Collections HTTP:",
        collections_result[
            "status"
        ]
    )

    if (
        collections_result[
            "status"
        ]
        != 200
    ):

        print(
            collections_result[
                "text"
            ][:500]
        )

        raise SystemExit(1)

    collections_json = parse_json(
        collections_result[
            "text"
        ]
    )

    if isinstance(
        collections_json,
        dict
    ):

        collections = (
            collections_json.get(
                "data",
                []
            )
        )

    elif isinstance(
        collections_json,
        list
    ):

        collections = (
            collections_json
        )

    else:

        print(
            "[-] Formato inesperado en listado de colecciones."
        )

        raise SystemExit(1)


    # ========================================================
    # RELACIONES DESDE COLECCIONES
    # ========================================================

    for collection in collections:

        owner = normalize_id(
            collection.get(
                "owner"
            )
        )

        updated_by = normalize_id(
            collection.get(
                "lastUpdatedBy"
            )
        )

        if owner:

            relationships[
                owner
            ].add(
                "collection_owner"
            )

        if updated_by:

            relationships[
                updated_by
            ].add(
                "collection_lastUpdatedBy"
            )


    # ========================================================
    # LOCALIZAR COLECCION ALERTADA
    # ========================================================

    target_collection = None

    for collection in collections:

        current_id = str(
            collection.get(
                "id",
                ""
            )
        )

        if (
            current_id
            == str(
                collection_id
            )
            or current_id.endswith(
                str(
                    collection_id
                )
            )
        ):

            target_collection = (
                collection
            )

            break

    if not target_collection:

        print(
            "[-] No se encontró la colección asociada a la alerta."
        )

        raise SystemExit(1)

    target_requests = (
        target_collection.get(
            "requests"
        )
        or []
    )


    # ========================================================
    # RECOPILAR REQUESTS COMPLETAS
    # ========================================================

    collected_requests = []
    errors = []

    total_requests = len(
        target_requests
    )

    CURRENT_STAGE = "request_collection"
    update_case_status("collecting", CURRENT_STAGE)

    print()
    print(
        "[+] Recopilando detalle de requests..."
    )

    for index, request_index in enumerate(
        target_requests,
        start=1
    ):

        request_id = (
            request_index.get(
                "id"
            )
        )

        request_endpoint = (
            "https://www.postman.com/"
            "_api/request/"
            f"{request_id}?populate=parent"
        )

        print(
            f"[{index}/{total_requests}]",
            request_index.get(
                "method"
            ),
            request_index.get(
                "name"
            )
        )

        try:

            detail_result = authenticated_get(
                request_endpoint
            )

            if (
                detail_result[
                    "status"
                ]
                == 200
            ):

                detail_json = parse_json(
                    detail_result[
                        "text"
                    ]
                )

                collected_requests.append(
                    detail_json
                )

                detail_data = (
                    detail_json.get(
                        "data"
                    )
                    or {}
                )

                owner = normalize_id(
                    detail_data.get(
                        "owner"
                    )
                )

                updated_by = normalize_id(
                    detail_data.get(
                        "lastUpdatedBy"
                    )
                )

                if owner:

                    relationships[
                        owner
                    ].add(
                        "request_owner"
                    )

                if updated_by:

                    relationships[
                        updated_by
                    ].add(
                        "request_lastUpdatedBy"
                    )

                print(
                    "       OK"
                )

            else:

                errors.append({
                    "id": request_id,
                    "name": request_index.get(
                        "name"
                    ),
                    "status": detail_result[
                        "status"
                    ]
                })

                print(
                    "       ERROR"
                )

        except Exception as exc:

            errors.append({
                "id": request_id,
                "name": request_index.get(
                    "name"
                ),
                "error": str(
                    exc
                )
            })

            print(
                "       ERROR:",
                exc
            )

        time.sleep(
            0.25
        )


    # ========================================================
    # SELECCIONAR METADATA WORKSPACE
    # ========================================================

    best_workspace = None
    best_score = -1

    for candidate in workspace_metadata_candidates:

        candidate_id = normalize_id(
            candidate.get(
                "id"
            )
        )

        if (
            candidate_id
            and candidate_id
            != workspace_id
        ):
            continue

        score = 0

        for key in [
            "name",
            "createdBy",
            "updatedBy",
            "createdAt",
            "updatedAt",
            "visibilityStatus",
            "state",
            "lastActivityTime",
            "contributors",
            "profileInfo",
            "team"
        ]:

            if candidate.get(
                key
            ) is not None:
                score += 1

        if score > best_score:

            best_score = score

            best_workspace = (
                candidate
            )

    if best_workspace is None:
        best_workspace = {}


    # ========================================================
    # PERFILES RELACIONADOS
    # ========================================================

    relevant_user_ids = set(
        relationships.keys()
    )

    relevant_user_ids.update(
        presence_user_ids
    )

    for candidate_map in workspace_user_map_candidates:

        for uid in relevant_user_ids:

            profile = (
                candidate_map.get(
                    uid
                )
            )

            if profile:

                existing = (
                    profiles_observed.get(
                        uid
                    )
                )

                if (
                    existing is None
                    or profile_score(
                        profile
                    )
                    > profile_score(
                        existing
                    )
                ):

                    profiles_observed[
                        uid
                    ] = profile


    # ========================================================
    # EMAILS RELACIONADOS
    # ========================================================

    related_emails = []

    for entry in extract_emails(
        best_workspace
    ):

        entry[
            "source"
        ] = "workspace_metadata"

        related_emails.append(
            entry
        )

    for entry in extract_emails(
        target_collection
    ):

        entry[
            "source"
        ] = "alerted_collection"

        related_emails.append(
            entry
        )

    for index, request_detail_item in enumerate(
        collected_requests,
        start=1
    ):

        request_name_for_email = (
            request_detail_item.get(
                "data",
                {}
            ).get(
                "name"
            )
        )

        for entry in extract_emails(
            request_detail_item
        ):

            entry[
                "source"
            ] = (
                "request:"
                + str(
                    request_name_for_email
                    or index
                )
            )

            related_emails.append(
                entry
            )

    related_emails = (
        unique_email_entries(
            related_emails
        )
    )


    # ========================================================
    # WORKSPACE SCOPE
    # ========================================================

    workspace_request_count = 0
    collection_summaries = []

    for collection in collections:

        reqs = (
            collection.get(
                "requests"
            )
            or []
        )

        workspace_request_count += len(
            reqs
        )

        collection_summaries.append({
            "id": collection.get(
                "id"
            ),

            "name": collection.get(
                "name"
            ),

            "owner": collection.get(
                "owner"
            ),

            "lastUpdatedBy": collection.get(
                "lastUpdatedBy"
            ),

            "createdAt": collection.get(
                "createdAt"
            ),

            "updatedAt": collection.get(
                "updatedAt"
            ),

            "request_count": len(
                reqs
            ),

            "requests": reqs,

            "folders": (
                collection.get(
                    "folders"
                )
                or []
            ),

            "attributes": (
                collection.get(
                    "attributes"
                )
                or {}
            )
        })


    # ========================================================
    # REQUEST INDEX
    # ========================================================

    request_index = []

    for request_detail_item in collected_requests:

        data = (
            request_detail_item.get(
                "data"
            )
            or {}
        )

        request_index.append({
            "id": data.get(
                "id"
            ),

            "name": data.get(
                "name"
            ),

            "method": data.get(
                "method"
            ),

            "url": data.get(
                "url"
            ),

            "owner": data.get(
                "owner"
            ),

            "lastUpdatedBy": data.get(
                "lastUpdatedBy"
            ),

            "createdAt": data.get(
                "createdAt"
            ),

            "updatedAt": data.get(
                "updatedAt"
            )
        })


    # ========================================================
    # IDENTIDADES
    # ========================================================

    identity_records = []

    for uid in sorted(
        relevant_user_ids
    ):

        profile = (
            profiles_observed.get(
                uid,
                {}
            )
        )

        rels = sorted(
            relationships.get(
                uid,
                set()
            )
        )

        direct_relationships = [
            rel
            for rel in rels
            if rel != "workspace_presence"
        ]

        if direct_relationships:

            category = (
                "direct_attribution"
            )

        elif (
            uid
            in presence_user_ids
        ):

            category = (
                "workspace_context"
            )

        else:

            category = (
                "related"
            )

        identity_records.append({
            "user_id": uid,

            "category": category,

            "relationships": rels,

            "profile": {
                "name": profile.get(
                    "name"
                ),

                "username": profile.get(
                    "username"
                ),

                "slug": profile.get(
                    "slug"
                ),

                "public_handle": profile.get(
                    "public_handle"
                ),

                "is_public": profile.get(
                    "is_public"
                ),

                "is_accessible": profile.get(
                    "is_accessible"
                )
            }
        })


    # ========================================================
    # ESCRIBIR RAW WORKSPACE
    # ========================================================

    workspace_output = {
        "source": {
            "case_id": CASE_ID,
            "alert_url": ALERT_URL,
            "workspace_id": workspace_id
        },

        "workspace": {
            "id": workspace_id,

            "name": (
                best_workspace.get(
                    "name"
                )
            ),

            "description": (
                best_workspace.get(
                    "description"
                )
            ),

            "summary": (
                best_workspace.get(
                    "summary"
                )
            ),

            "visibilityStatus": (
                best_workspace.get(
                    "visibilityStatus"
                )
            ),

            "state": (
                best_workspace.get(
                    "state"
                )
            ),

            "isArchived": (
                best_workspace.get(
                    "isArchived"
                )
            ),

            "team": (
                best_workspace.get(
                    "team"
                )
            ),

            "profileInfo": (
                best_workspace.get(
                    "profileInfo"
                )
            ),

            "createdBy": (
                best_workspace.get(
                    "createdBy"
                )
            ),

            "updatedBy": (
                best_workspace.get(
                    "updatedBy"
                )
            ),

            "contributors": (
                best_workspace.get(
                    "contributors"
                )
            ),

            "timeline": {
                "createdAt": (
                    best_workspace.get(
                        "createdAt"
                    )
                ),

                "updatedAt": (
                    best_workspace.get(
                        "updatedAt"
                    )
                ),

                "lastActivityTime": (
                    best_workspace.get(
                        "lastActivityTime"
                    )
                )
            }
        },

        "alerted_resource": {
            "type": ALERT_TYPE,

            "resource_uid": (
                RESOURCE_UID
            ),

            "request_uid": (
                REQUEST_UID
            ),

            "request_name": (
                request_name
            ),

            "collection_uid": (
                COLLECTION_UID
            ),

            "collection_id": (
                collection_id
            ),

            "collection_name": (
                collection_name
            )
        },

        "scope": {
            "collections": len(
                collections
            ),

            "requests": (
                workspace_request_count
            ),

            "alerted_collection_requests": (
                total_requests
            )
        },

        "collections": (
            collection_summaries
        )
    }

    with open(
        RAW_WORKSPACE_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            workspace_output,
            file,
            indent=2,
            ensure_ascii=False
        )


    # ========================================================
    # ESCRIBIR RAW IDENTITY
    # ========================================================

    identity_output = {
        "source": {
            "case_id": CASE_ID,
            "alert_url": ALERT_URL,
            "workspace_id": workspace_id
        },

        "identities": (
            identity_records
        ),

        "emails_from_related_evidence": (
            related_emails
        )
    }

    with open(
        RAW_IDENTITY_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            identity_output,
            file,
            indent=2,
            ensure_ascii=False
        )


    # ========================================================
    # ESCRIBIR COLLECTION DUMP
    # ========================================================

    collection_output = {
        "source": {
            "case_id": CASE_ID,
            "alert_url": ALERT_URL,
            "workspace_id": workspace_id
        },

        "alert": {
            "type": ALERT_TYPE,
            "resource_uid": RESOURCE_UID,
            "request_uid": REQUEST_UID,
            "request_name": request_name,
            "collection_uid": COLLECTION_UID
        },

        "alerted_request": {
            "uid": REQUEST_UID,
            "name": request_name
        },

        "collection": {
            "id": collection_id,
            "name": collection_name,

            "createdAt": (
                target_collection.get(
                    "createdAt"
                )
            ),

            "updatedAt": (
                target_collection.get(
                    "updatedAt"
                )
            )
        },

        "collection_detail": (
            alerted_collection_context
        ),

        "summary": {
            "requests_discovered": (
                total_requests
            ),

            "requests_collected": (
                len(
                    collected_requests
                )
            ),

            "errors": len(
                errors
            )
        },

        "request_index": (
            request_index
        ),

        "requests": (
            collected_requests
        ),

        "errors": (
            errors
        )
    }

    with open(
        COLLECTION_DUMP_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            collection_output,
            file,
            indent=2,
            ensure_ascii=False
        )


    # ========================================================
    # FINALIZAR CASE INFO
    # ========================================================

    case_info = {
        "case_id": CASE_ID,

        "collected_at_lima": (
            now.isoformat(
                timespec="seconds"
            )
        ),

        "alert_url": ALERT_URL,

        "alert_type": ALERT_TYPE,

        "resource_uid": RESOURCE_UID,

        "request_uid": REQUEST_UID,

        "collection_uid": COLLECTION_UID,

        "workspace_id": workspace_id,

        "workspace_name": (
            best_workspace.get(
                "name"
            )
        ),

        "collection_id": collection_id,

        "collection_name": collection_name,

        "request_name": request_name,

        "scope": {
            "workspace_collections": (
                len(
                    collections
                )
            ),

            "workspace_requests": (
                workspace_request_count
            ),

            "alerted_collection_requests": (
                total_requests
            )
        },

        "collection_errors": (
            len(
                errors
            )
        ),

        "status": "completed",
        "stage": "completed"
    }

    with open(
        CASE_INFO_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            case_info,
            file,
            indent=2,
            ensure_ascii=False
        )


    # ========================================================
    # RESULTADO
    # ========================================================

    print()
    print(
        "========================================"
    )
    print(
        "RESULTADO DEL RECOLECTOR"
    )
    print(
        "========================================"
    )

    print(
        "[+] Case ID:",
        CASE_ID
    )

    print(
        "[+] Carpeta:",
        CASE_DIR
    )

    print(
        "[+] Workspace:",
        best_workspace.get(
            "name"
        )
    )

    print(
        "[+] Workspace collections:",
        len(
            collections
        )
    )

    print(
        "[+] Workspace requests:",
        workspace_request_count
    )

    print(
        "[+] Requests coleccion alertada:",
        total_requests
    )

    print(
        "[+] Requests recopiladas:",
        len(
            collected_requests
        )
    )

    print(
        "[+] Errores:",
        len(
            errors
        )
    )

    print()
    print(
        "[+] Archivos:"
    )

    print(
        "   -",
        CASE_INFO_FILE
    )

    print(
        "   -",
        RAW_WORKSPACE_FILE
    )

    print(
        "   -",
        RAW_IDENTITY_FILE
    )

    print(
        "   -",
        COLLECTION_DUMP_FILE
    )
