import json
import math
import re
import sys
from pathlib import Path
from collections import Counter, defaultdict
from urllib.parse import urlparse, parse_qsl
from datetime import datetime
from zoneinfo import ZoneInfo


# ============================================================
# CONFIGURACION
# ============================================================

LIMA_TZ = ZoneInfo("America/Lima")

if len(sys.argv) != 2:
    print("Uso:")
    print("  python analyze.py <CARPETA_DEL_CASO>")
    print()
    print("Ejemplo:")
    print("  python analyze.py cases/20260828_091534_46267037-04758603-/")
    raise SystemExit(1)


CASE_DIR = Path(sys.argv[1])

if not CASE_DIR.exists():
    print("[-] La carpeta indicada no existe:")
    print("   ", CASE_DIR)
    raise SystemExit(1)


CASE_INFO_FILE = CASE_DIR / "case_info.json"
RAW_WORKSPACE_FILE = CASE_DIR / "raw_workspace.json"
RAW_IDENTITY_FILE = CASE_DIR / "raw_identity.json"
COLLECTION_DUMP_FILE = CASE_DIR / "collection_dump.json"

OUTPUT_FILE = CASE_DIR / "analysis.txt"


# ============================================================
# PATRONES
# ============================================================

EMAIL_RE = re.compile(
    r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"
)

PRIVATE_IP_RE = re.compile(
    r"\b(?:"
    r"10\.\d{1,3}\.\d{1,3}\.\d{1,3}"
    r"|192\.168\.\d{1,3}\.\d{1,3}"
    r"|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}"
    r")\b"
)

INTERNAL_HOST_RE = re.compile(
    r"\b(?:[A-Za-z0-9-]+\.)+"
    r"(?:internal|local|corp|lan|inet)\b",
    re.IGNORECASE
)

JWT_RE = re.compile(
    r"\beyJ[A-Za-z0-9_-]+\."
    r"[A-Za-z0-9_-]+\."
    r"[A-Za-z0-9_-]+\b"
)


SENSITIVE_KEY_WORDS = [
    "authorization",
    "password",
    "passwd",
    "secret",
    "token",
    "apikey",
    "api-key",
    "api_key",
    "client-secret",
    "client_secret",
    "client-id",
    "client_id",
    "credential",
    "cookie",
    "session",
    "bearer",
    "private-key",
    "private_key",
]


PERSONAL_KEY_WORDS = [
    "email",
    "mail",
    "phone",
    "mobile",
    "telephone",
    "document",
    "documentnumber",
    "document_number",
    "dni",
    "passport",
    "address",
    "firstname",
    "first_name",
    "lastname",
    "last_name",
    "fullname",
    "full_name",
]


ENVIRONMENT_WORDS = [
    "development",
    "testing",
    "staging",
    "preprod",
    "production",
    "uat",
    "qa",
    "dev",
    "test",
    "prod",
]


UUID_RE = re.compile(
    r"\b[0-9a-fA-F]{8}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{12}\b"
)


PEM_PRIVATE_KEY_RE = re.compile(
    r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
    re.IGNORECASE
)


URL_CREDENTIAL_RE = re.compile(
    r"https?://[^/\s:@]+:[^@\s/]+@",
    re.IGNORECASE
)


BEARER_LITERAL_RE = re.compile(
    r"\bBearer\s+([A-Za-z0-9._~+/=-]{16,})\b",
    re.IGNORECASE
)


BASIC_AUTH_RE = re.compile(
    r"\bBasic\s+([A-Za-z0-9+/]{12,}={0,2})\b",
    re.IGNORECASE
)


GOOGLE_API_KEY_RE = re.compile(
    r"\bAIza[0-9A-Za-z_-]{35}\b"
)


AZURE_SAS_RE = re.compile(
    r"(?:^|[?&])"
    r"(?:sv|sp|se|sr|sig)=",
    re.IGNORECASE
)


COMMON_SECRET_PATTERNS = [
    (
        "AWS Access Key",
        re.compile(r"\bAKIA[0-9A-Z]{16}\b")
    ),
    (
        "GitHub Token",
        re.compile(
            r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"
        )
    ),
    (
        "Slack Token",
        re.compile(
            r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b"
        )
    ),
]


TECHNOLOGY_RULES = [
    (
        "Microsoft Azure",
        [
            "azure.com",
            "azurewebsites.net",
            "cloudapp.azure.com",
            "azure-api.net"
        ]
    ),
    (
        "AKS / Kubernetes",
        [
            "aks",
            "kubernetes",
            "k8s"
        ]
    ),
    (
        "Amazon Web Services",
        [
            "amazonaws.com",
            "aws"
        ]
    ),
    (
        "Google Cloud",
        [
            "googleapis.com",
            "gcp"
        ]
    ),
    (
        "IBM API Connect",
        [
            "x-ibm-client-id",
            "x-ibm-client-secret",
            "ibm api connect"
        ]
    ),
]


TECHNICAL_HEADER_PREFIXES = [
    "unica-",
    "x-ibm-",
    "x-api-",
    "x-correlation-",
    "x-request-",
    "x-trace-",
]


# ============================================================
# UTILIDADES
# ============================================================

def load_json(path):
    if not path.exists():
        print("[-] No se encontró:")
        print("   ", path)
        raise SystemExit(1)

    try:
        with open(path, encoding="utf-8") as file:
            return json.load(file)

    except Exception as exc:
        print("[-] No se pudo leer:")
        print("   ", path)
        print("   ", exc)
        raise SystemExit(1)


def format_date_lima(value):
    """
    Convierte timestamps ISO de Postman a hora de Lima.

    Los timestamps terminados en Z o sin offset se interpretan
    como UTC, ya que Postman devuelve estas fechas en UTC.
    """

    if not value:
        return "No identificado"

    try:
        text = str(value)

        if text.endswith("Z"):
            text = text[:-1] + "+00:00"

        dt = datetime.fromisoformat(text)

        if dt.tzinfo is None:
            dt = dt.replace(
                tzinfo=ZoneInfo("UTC")
            )

        lima_dt = dt.astimezone(
            LIMA_TZ
        )

        return lima_dt.strftime(
            "%d/%m/%Y %H:%M (Lima)"
        )

    except Exception:
        return str(value)


def mask_value(value):
    if value is None:
        return "No identificado"

    text = str(value)

    # Referencias a variables/Vault no son el secreto real.
    if "{{" in text and "}}" in text:
        return text

    if len(text) == 0:
        return ""

    if len(text) <= 6:
        return "*" * len(text)

    if len(text) <= 10:
        return (
            text[:2]
            + "..."
            + text[-2:]
        )

    return (
        text[:4]
        + "..."
        + text[-4:]
    )


def classify_value(value):
    if value is None:
        return "empty"

    text = str(value).strip()

    if not text:
        return "empty"

    lower = text.lower()

    if "{{vault:" in lower:
        return "vault_reference"

    if "{{" in text and "}}" in text:
        return "variable_reference"

    if "${" in text and "}" in text:
        return "variable_reference"

    if JWT_RE.search(text):
        return "literal_token"

    return "literal"


def contains_word(key, words):
    if key is None:
        return False

    normalized = (
        str(key)
        .lower()
        .replace(" ", "")
    )

    return any(
        word in normalized
        for word in words
    )


def walk_values(obj, path=""):
    results = []

    if isinstance(obj, dict):

        for key, value in obj.items():

            current_path = (
                f"{path}.{key}"
                if path
                else str(key)
            )

            if isinstance(
                value,
                (dict, list)
            ):
                results.extend(
                    walk_values(
                        value,
                        current_path
                    )
                )

            else:
                results.append({
                    "path": current_path,
                    "key": str(key),
                    "value": value
                })

    elif isinstance(obj, list):

        for index, value in enumerate(obj):

            current_path = (
                f"{path}[{index}]"
                if path
                else f"[{index}]"
            )

            if isinstance(
                value,
                (dict, list)
            ):
                results.extend(
                    walk_values(
                        value,
                        current_path
                    )
                )

            else:
                results.append({
                    "path": current_path,
                    "key": str(index),
                    "value": value
                })

    return results


def severity_for_credential(
    key,
    classification
):
    lower = str(
        key or ""
    ).lower()

    if classification in [
        "vault_reference",
        "variable_reference"
    ]:
        return "LOW"

    if classification == "literal_token":
        return "HIGH"

    if classification == "literal":

        high_terms = [
            "password",
            "passwd",
            "secret",
            "authorization",
            "token",
            "apikey",
            "api-key",
            "api_key",
            "private"
        ]

        if any(
            term in lower
            for term in high_terms
        ):
            return "HIGH"

        if (
            "client" in lower
            and "id" in lower
        ):
            return "MEDIUM"

        return "MEDIUM"

    return "INFO"


def readable_relationship(rel):
    translations = {
        "workspace_createdBy":
            "Creador del workspace",

        "workspace_updatedBy":
            "Último usuario que actualizó el workspace",

        "workspace_user":
            "Usuario asociado al workspace",

        "workspace_contributor:user":
            "Contributor del workspace",

        "collection_owner":
            "Owner de las colecciones",

        "collection_lastUpdatedBy":
            "Último usuario que actualizó las colecciones",

        "request_owner":
            "Owner de las requests analizadas",

        "request_lastUpdatedBy":
            "Último usuario que actualizó las requests",

        "alerted_request_owner":
            "Owner de la request que originó la alerta",

        "alerted_request_lastUpdatedBy":
            "Último usuario que actualizó la request alertada",

        "alerted_collection_owner":
            "Owner de la colección que originó la alerta",

        "alerted_collection_lastUpdatedBy":
            "Último usuario que actualizó la colección alertada",

        "workspace_presence":
            "Perfil observado en el contexto del workspace"
    }

    return translations.get(
        rel,
        rel
    )



def detect_technologies(text):
    if text is None:
        return []

    lower = str(text).lower()

    detected = []

    for technology, indicators in TECHNOLOGY_RULES:
        if any(
            indicator.lower() in lower
            for indicator in indicators
        ):
            detected.append(
                technology
            )

    return detected


def is_technical_header(key):
    if not key:
        return False

    lower = str(key).lower()

    return any(
        lower.startswith(prefix)
        for prefix in TECHNICAL_HEADER_PREFIXES
    )


def detect_secret_patterns(value):
    if value is None:
        return []

    text = str(value)

    output = []

    if JWT_RE.search(text):
        output.append(
            "JWT"
        )

    if PEM_PRIVATE_KEY_RE.search(text):
        output.append(
            "Private Key"
        )

    if URL_CREDENTIAL_RE.search(text):
        output.append(
            "Credenciales embebidas en URL"
        )

    if BEARER_LITERAL_RE.search(text):
        output.append(
            "Bearer Token"
        )

    if BASIC_AUTH_RE.search(text):
        output.append(
            "Basic Authorization"
        )

    if GOOGLE_API_KEY_RE.search(text):
        output.append(
            "Google API Key"
        )

    # SAS de Azure: exigimos varios componentes para
    # reducir falsos positivos por un parámetro aislado.
    lower_text = text.lower()

    sas_markers = [
        "sv=",
        "sig=",
        "se="
    ]

    if sum(
        marker in lower_text
        for marker in sas_markers
    ) >= 2:

        output.append(
            "Azure SAS Token"
        )

    for name, pattern in COMMON_SECRET_PATTERNS:
        if pattern.search(text):
            output.append(
                name
            )

    return output


def contextual_value(value):
    """
    Ofusca únicamente valores que puedan ser excesivamente
    largos. Los identificadores técnicos se conservan como
    evidencia cuando no corresponden a secretos.
    """

    if value is None:
        return "No identificado"

    text = str(value)

    if len(text) > 160:
        return (
            text[:150]
            + "..."
        )

    return text



def shannon_entropy(value):
    if value is None:
        return 0.0

    text = str(value)

    if not text:
        return 0.0

    counts = Counter(text)

    entropy = 0.0

    for count in counts.values():
        probability = count / len(text)

        entropy -= (
            probability
            * math.log2(probability)
        )

    return entropy


def looks_like_high_entropy_secret(
    key,
    value
):
    """
    Heurística conservadora para valores aparentemente secretos.

    Solo se activa cuando el nombre del campo tiene contexto
    sensible y el valor presenta suficiente longitud,
    variedad de caracteres y entropía.
    """

    if value is None:
        return False

    text = str(value).strip()

    if len(text) < 20:
        return False

    if not contains_word(
        key,
        SENSITIVE_KEY_WORDS
    ):
        return False

    if classify_value(text) != "literal":
        return False

    classes = 0

    if re.search(r"[a-z]", text):
        classes += 1

    if re.search(r"[A-Z]", text):
        classes += 1

    if re.search(r"[0-9]", text):
        classes += 1

    if re.search(
        r"[^A-Za-z0-9]",
        text
    ):
        classes += 1

    if classes < 3:
        return False

    return (
        shannon_entropy(text)
        >= 3.5
    )


def normalize_headers(data):
    """
    Usa headerData cuando está disponible y headers como fallback.
    """

    raw = (
        data.get("headerData")
        or data.get("headers")
        or []
    )

    if isinstance(raw, list):
        return raw

    if isinstance(raw, dict):

        return [
            {
                "key": key,
                "value": value,
                "type": "text"
            }
            for key, value in raw.items()
        ]

    if isinstance(raw, str):

        # Intentar JSON.
        try:

            parsed = json.loads(raw)

            if isinstance(parsed, list):
                return parsed

            if isinstance(parsed, dict):

                return [
                    {
                        "key": key,
                        "value": value,
                        "type": "text"
                    }
                    for key, value in parsed.items()
                ]

        except Exception:
            pass

        # Intentar formato Header: Value
        result = []

        for line in raw.splitlines():

            if ":" not in line:
                continue

            key, value = line.split(
                ":",
                1
            )

            result.append({
                "key": key.strip(),
                "value": value.strip(),
                "type": "text"
            })

        return result

    return []


def human_credential_text(
    key,
    classification
):
    if classification == "vault_reference":
        return (
            "Se observa una referencia a un secreto almacenado "
            "en Postman Vault. El valor real del secreto no está "
            "expuesto directamente."
        )

    if classification == "variable_reference":
        return (
            "Se observa una referencia a una variable. "
            "El valor real no está expuesto directamente "
            "en el recurso analizado."
        )

    if classification == "literal_token":
        return (
            "Se identificó un token almacenado directamente "
            "como texto en el recurso publicado."
        )

    if classification == "literal":
        return (
            "El valor se encuentra expuesto directamente en "
            "el recurso publicado. Se recomienda validar su "
            "sensibilidad y vigencia."
        )

    return (
        "Se identificó información relacionada con "
        "autenticación."
    )


# ============================================================
# CARGA
# ============================================================

case_info = load_json(
    CASE_INFO_FILE
)

workspace_raw = load_json(
    RAW_WORKSPACE_FILE
)

identity_raw = load_json(
    RAW_IDENTITY_FILE
)

collection_raw = load_json(
    COLLECTION_DUMP_FILE
)


workspace = (
    workspace_raw.get(
        "workspace"
    )
    or {}
)

scope = (
    workspace_raw.get(
        "scope"
    )
    or {}
)

alerted_resource = (
    workspace_raw.get(
        "alerted_resource"
    )
    or {}
)

ALERT_TYPE = (
    alerted_resource.get("type")
    or case_info.get("alert_type")
    or "request"
)

identities = (
    identity_raw.get(
        "identities"
    )
    or []
)

requests = (
    collection_raw.get(
        "requests"
    )
    or []
)

collection_detail = (
    collection_raw.get(
        "collection_detail"
    )
    or {}
)


# ============================================================
# ATRIBUCION
# ============================================================

direct_identities = []
context_identities = []

for identity in identities:

    profile = (
        identity.get(
            "profile"
        )
        or {}
    )

    record = {
        "user_id": identity.get(
            "user_id"
        ),

        "name": profile.get(
            "name"
        ),

        "username": profile.get(
            "username"
        ),

        "public_handle": profile.get(
            "public_handle"
        ),

        "relationships": (
            identity.get(
                "relationships"
            )
            or []
        )
    }

    if (
        identity.get(
            "category"
        )
        == "direct_attribution"
    ):
        direct_identities.append(
            record
        )

    elif (
        identity.get(
            "category"
        )
        == "workspace_context"
    ):
        context_identities.append(
            record
        )


# ============================================================
# COLECCIONES
# ============================================================

collection_summaries = []

for collection in (
    workspace_raw.get(
        "collections"
    )
    or []
):

    collection_summaries.append({
        "name": collection.get(
            "name"
        ),

        "request_count": collection.get(
            "request_count"
        ),

        "createdAt": collection.get(
            "createdAt"
        ),

        "updatedAt": collection.get(
            "updatedAt"
        )
    })


# ============================================================
# ANALISIS DE REQUESTS
# ============================================================

request_index = []

domains = Counter()
environments = Counter()

findings = []

context_evidence = []

technologies_observed = set()

technical_headers = {}

query_parameters = []

technical_identifiers = []


for item in requests:

    data = (
        item.get(
            "data"
        )
        or {}
    )

    request_name = data.get(
        "name"
    )

    method = data.get(
        "method"
    )

    url = data.get(
        "url"
    )

    request_index.append({
        "name": request_name,
        "method": method,
        "url": url,
        "createdAt": data.get(
            "createdAt"
        ),
        "updatedAt": data.get(
            "updatedAt"
        )
    })


    # --------------------------------------------------------
    # ENDPOINT / INFRAESTRUCTURA
    # --------------------------------------------------------

    if url:

        for technology in detect_technologies(
            url
        ):
            technologies_observed.add(
                technology
            )

        for secret_type in detect_secret_patterns(
            url
        ):

            findings.append({
                "severity": "HIGH",
                "category": "Autenticación / Credenciales",
                "request": request_name,
                "field": "URL",
                "classification": "literal_secret_pattern",
                "value": mask_value(
                    url
                ),
                "interpretation": (
                    f"Se identificó un patrón compatible con "
                    f"{secret_type} directamente en la URL publicada."
                )
            })

        parsed = urlparse(
            url
        )

        hostname = (
            parsed.hostname
            or ""
        )

        if hostname:
            domains[
                hostname
            ] += 1

        lower_url = (
            url.lower()
        )

        for candidate in (
            ENVIRONMENT_WORDS
        ):

            pattern = (
                r"(^|[/_.-])"
                + re.escape(
                    candidate
                )
                + r"($|[/_.-])"
            )

            if re.search(
                pattern,
                lower_url
            ):

                environments[
                    candidate
                ] += 1

                break

        for private_ip in (
            PRIVATE_IP_RE.findall(
                url
            )
        ):

            findings.append({
                "severity": "MEDIUM",
                "category": "Infraestructura interna",
                "request": request_name,
                "field": "Endpoint",
                "classification": "private_ip",
                "value": mask_value(
                    private_ip
                ),
                "interpretation": (
                    "La publicación revela una dirección IP "
                    "de rango privado asociada a infraestructura "
                    "interna."
                )
            })

        for internal_host in (
            INTERNAL_HOST_RE.findall(
                url
            )
        ):

            findings.append({
                "severity": "MEDIUM",
                "category": "Infraestructura interna",
                "request": request_name,
                "field": "Endpoint",
                "classification": "internal_hostname",
                "value": mask_value(
                    internal_host
                ),
                "interpretation": (
                    "La publicación revela un hostname con "
                    "características de infraestructura interna."
                )
            })


    # --------------------------------------------------------
    # HEADERS
    # --------------------------------------------------------

    for header in normalize_headers(
        data
    ):

        key = header.get(
            "key"
        )

        value = header.get(
            "value"
        )

        classification = (
            classify_value(
                value
            )
        )

        for technology in detect_technologies(
            f"{key} {value}"
        ):
            technologies_observed.add(
                technology
            )

        if is_technical_header(
            key
        ):

            header_key = str(
                key
            )

            if header_key not in technical_headers:
                technical_headers[
                    header_key
                ] = {
                    "values": set(),
                    "requests": set()
                }

            technical_headers[
                header_key
            ][
                "values"
            ].add(
                contextual_value(
                    value
                )
            )

            technical_headers[
                header_key
            ][
                "requests"
            ].add(
                request_name
            )

        if value:

            if UUID_RE.fullmatch(
                str(value).strip()
            ):
                technical_identifiers.append({
                    "type": "UUID",
                    "field": key,
                    "value": str(value),
                    "request": request_name
                })

            for secret_type in detect_secret_patterns(
                value
            ):

                findings.append({
                    "severity": "HIGH",
                    "category": "Autenticación / Credenciales",
                    "request": request_name,
                    "field": key,
                    "classification": "literal_secret_pattern",
                    "value": mask_value(
                        value
                    ),
                    "interpretation": (
                        f"Se identificó un patrón compatible con "
                        f"{secret_type} almacenado directamente "
                        f"en el header publicado."
                    )
                })

        if (
            value
            and looks_like_high_entropy_secret(
                key,
                value
            )
            and not detect_secret_patterns(
                value
            )
        ):

            findings.append({
                "severity": "HIGH",
                "category": "Autenticación / Credenciales",
                "request": request_name,
                "field": key,
                "classification": "high_entropy_secret",
                "value": mask_value(
                    value
                ),
                "interpretation": (
                    "Se identificó un valor literal con "
                    "características compatibles con un secreto "
                    "en un campo sensible."
                )
            })

        if contains_word(
            key,
            SENSITIVE_KEY_WORDS
        ):

            findings.append({
                "severity":
                    severity_for_credential(
                        key,
                        classification
                    ),

                "category":
                    "Autenticación / Credenciales",

                "request":
                    request_name,

                "field":
                    key,

                "classification":
                    classification,

                "value":
                    mask_value(
                        value
                    ),

                "interpretation":
                    human_credential_text(
                        key,
                        classification
                    )
            })

        if value:

            value_text = str(
                value
            )

            for private_ip in (
                PRIVATE_IP_RE.findall(
                    value_text
                )
            ):

                findings.append({
                    "severity": "MEDIUM",
                    "category": "Infraestructura interna",
                    "request": request_name,
                    "field": key,
                    "classification": "private_ip",
                    "value": mask_value(
                        private_ip
                    ),
                    "interpretation": (
                        "Se identificó una dirección IP privada "
                        "en un header publicado."
                    )
                })

            for internal_host in (
                INTERNAL_HOST_RE.findall(
                    value_text
                )
            ):

                findings.append({
                    "severity": "MEDIUM",
                    "category": "Infraestructura interna",
                    "request": request_name,
                    "field": key,
                    "classification": "internal_hostname",
                    "value": mask_value(
                        internal_host
                    ),
                    "interpretation": (
                        "Se identificó un hostname con "
                        "características de infraestructura "
                        "interna en un header."
                    )
                })

            for email in (
                EMAIL_RE.findall(
                    value_text
                )
            ):

                findings.append({
                    "severity": "MEDIUM",
                    "category": "Datos potencialmente sensibles",
                    "request": request_name,
                    "field": key,
                    "classification": "email",
                    "value": mask_value(
                        email
                    ),
                    "interpretation": (
                        "Se identificó una dirección de correo "
                        "dentro del contenido publicado."
                    )
                })


    # --------------------------------------------------------
    # QUERY PARAMETERS
    # --------------------------------------------------------

    for query_param in (
        data.get(
            "queryParams"
        )
        or []
    ):

        if not isinstance(
            query_param,
            dict
        ):
            continue

        param_key = (
            query_param.get(
                "key"
            )
        )

        param_value = (
            query_param.get(
                "value"
            )
        )

        enabled = (
            query_param.get(
                "enabled",
                True
            )
        )

        query_parameters.append({
            "request": request_name,
            "key": param_key,
            "value": contextual_value(
                param_value
            ),
            "enabled": enabled
        })

        for technology in detect_technologies(
            f"{param_key} {param_value}"
        ):
            technologies_observed.add(
                technology
            )

        classification = classify_value(
            param_value
        )

        if contains_word(
            param_key,
            PERSONAL_KEY_WORDS
        ):

            findings.append({
                "severity": "MEDIUM",
                "category": "Datos potencialmente sensibles",
                "request": request_name,
                "field": f"queryParams.{param_key}",
                "classification": classification,
                "value": mask_value(
                    param_value
                ),
                "interpretation": (
                    "Se identificó un parámetro que podría "
                    "contener información personal o "
                    "identificativa."
                )
            })

        if contains_word(
            param_key,
            SENSITIVE_KEY_WORDS
        ):

            findings.append({
                "severity":
                    severity_for_credential(
                        param_key,
                        classification
                    ),

                "category":
                    "Autenticación / Credenciales",

                "request":
                    request_name,

                "field":
                    f"queryParams.{param_key}",

                "classification":
                    classification,

                "value":
                    mask_value(
                        param_value
                    ),

                "interpretation":
                    (
                        human_credential_text(
                            param_key,
                            classification
                        )
                        + (
                            " El parámetro se encuentra "
                            "deshabilitado en la colección, "
                            "pero continúa visible en el "
                            "recurso publicado."
                            if enabled is False
                            else ""
                        )
                    )
            })

        if param_value:

            for secret_type in detect_secret_patterns(
                param_value
            ):

                findings.append({
                    "severity": "HIGH",
                    "category": "Autenticación / Credenciales",
                    "request": request_name,
                    "field":
                        f"queryParams.{param_key}",
                    "classification":
                        "literal_secret_pattern",
                    "value":
                        mask_value(
                            param_value
                        ),
                    "interpretation":
                        (
                            f"Se identificó un patrón compatible "
                            f"con {secret_type} dentro de un "
                            f"parámetro de URL publicado."
                        )
                })

            value_text = str(
                param_value
            )

            for email in (
                EMAIL_RE.findall(
                    value_text
                )
            ):

                findings.append({
                    "severity": "MEDIUM",
                    "category": "Datos potencialmente sensibles",
                    "request": request_name,
                    "field": f"queryParams.{param_key}",
                    "classification": "email",
                    "value": mask_value(
                        email
                    ),
                    "interpretation": (
                        "Se identificó una dirección de correo "
                        "en un parámetro publicado."
                    )
                })

            for private_ip in (
                PRIVATE_IP_RE.findall(
                    value_text
                )
            ):

                findings.append({
                    "severity": "MEDIUM",
                    "category": "Infraestructura interna",
                    "request": request_name,
                    "field": f"queryParams.{param_key}",
                    "classification": "private_ip",
                    "value": mask_value(
                        private_ip
                    ),
                    "interpretation": (
                        "Se identificó una dirección IP privada "
                        "en un parámetro publicado."
                    )
                })

            for internal_host in (
                INTERNAL_HOST_RE.findall(
                    value_text
                )
            ):

                findings.append({
                    "severity": "MEDIUM",
                    "category": "Infraestructura interna",
                    "request": request_name,
                    "field": f"queryParams.{param_key}",
                    "classification": "internal_hostname",
                    "value": mask_value(
                        internal_host
                    ),
                    "interpretation": (
                        "Se identificó un hostname interno "
                        "en un parámetro publicado."
                    )
                })

            if UUID_RE.fullmatch(
                str(param_value).strip()
            ):

                technical_identifiers.append({
                    "type": "UUID",
                    "field": param_key,
                    "value": str(param_value),
                    "request": request_name
                })


    # --------------------------------------------------------
    # BODY
    # --------------------------------------------------------

    raw_body = data.get(
        "rawModeData"
    )

    if raw_body:

        try:

            parsed_body = json.loads(
                raw_body
            )

            body_values = walk_values(
                parsed_body
            )

        except Exception:

            body_values = [{
                "path": "rawModeData",
                "key": "rawModeData",
                "value": raw_body
            }]

        for entry in body_values:

            key = entry.get(
                "key"
            )

            value = entry.get(
                "value"
            )

            path = entry.get(
                "path"
            )

            classification = (
                classify_value(
                    value
                )
            )

            for technology in detect_technologies(
                f"{key} {value}"
            ):
                technologies_observed.add(
                    technology
                )

            if value:

                if UUID_RE.fullmatch(
                    str(value).strip()
                ):
                    technical_identifiers.append({
                        "type": "UUID",
                        "field": path,
                        "value": str(value),
                        "request": request_name
                    })

                for secret_type in detect_secret_patterns(
                    value
                ):

                    findings.append({
                        "severity": "HIGH",
                        "category": "Autenticación / Credenciales",
                        "request": request_name,
                        "field": path,
                        "classification":
                            "literal_secret_pattern",
                        "value":
                            mask_value(
                                value
                            ),
                        "interpretation":
                            (
                                f"Se identificó un patrón compatible "
                                f"con {secret_type} directamente "
                                f"en el contenido publicado."
                            )
                    })

            if contains_word(
                key,
                SENSITIVE_KEY_WORDS
            ):

                findings.append({
                    "severity":
                        severity_for_credential(
                            key,
                            classification
                        ),

                    "category":
                        "Autenticación / Credenciales",

                    "request":
                        request_name,

                    "field":
                        path,

                    "classification":
                        classification,

                    "value":
                        mask_value(
                            value
                        ),

                    "interpretation":
                        human_credential_text(
                            key,
                            classification
                        )
                })

            if contains_word(
                key,
                PERSONAL_KEY_WORDS
            ):

                findings.append({
                    "severity": "MEDIUM",
                    "category": "Datos potencialmente sensibles",
                    "request": request_name,
                    "field": path,
                    "classification": classification,
                    "value": mask_value(
                        value
                    ),
                    "interpretation": (
                        "Se identificó un campo que podría contener "
                        "información personal o identificativa."
                    )
                })

            if value:

                value_text = str(
                    value
                )

                for email in (
                    EMAIL_RE.findall(
                        value_text
                    )
                ):

                    findings.append({
                        "severity": "MEDIUM",
                        "category": "Datos potencialmente sensibles",
                        "request": request_name,
                        "field": path,
                        "classification": "email",
                        "value": mask_value(
                            email
                        ),
                        "interpretation": (
                            "Se identificó una dirección de correo "
                            "en el contenido publicado."
                        )
                    })

                for private_ip in (
                    PRIVATE_IP_RE.findall(
                        value_text
                    )
                ):

                    findings.append({
                        "severity": "MEDIUM",
                        "category": "Infraestructura interna",
                        "request": request_name,
                        "field": path,
                        "classification": "private_ip",
                        "value": mask_value(
                            private_ip
                        ),
                        "interpretation": (
                            "Se identificó una dirección IP privada "
                            "en el contenido publicado."
                        )
                    })

                for internal_host in (
                    INTERNAL_HOST_RE.findall(
                        value_text
                    )
                ):

                    findings.append({
                        "severity": "MEDIUM",
                        "category": "Infraestructura interna",
                        "request": request_name,
                        "field": path,
                        "classification": "internal_hostname",
                        "value": mask_value(
                            internal_host
                        ),
                        "interpretation": (
                            "Se identificó un hostname con "
                            "características de infraestructura "
                            "interna en el contenido publicado."
                        )
                    })


    # --------------------------------------------------------
    # OTRAS SECCIONES
    # --------------------------------------------------------

    extra_sections = {
        "auth": data.get(
            "auth"
        ),

        "variables": data.get(
            "variables"
        ),

        "preRequestScript": data.get(
            "preRequestScript"
        ),

        "tests": data.get(
            "tests"
        ),

        "events": data.get(
            "events"
        ),
    }

    for section_name, section_value in (
        extra_sections.items()
    ):

        if section_value is None:
            continue

        for entry in walk_values(
            section_value
        ):

            key = entry.get(
                "key"
            )

            value = entry.get(
                "value"
            )

            path = (
                f"{section_name}."
                f"{entry.get('path')}"
            )

            classification = (
                classify_value(
                    value
                )
            )

            if value:

                for secret_type in detect_secret_patterns(
                    value
                ):

                    findings.append({
                        "severity": "HIGH",
                        "category": "Autenticación / Credenciales",
                        "request": request_name,
                        "field": path,
                        "classification": "literal_secret_pattern",
                        "value": mask_value(
                            value
                        ),
                        "interpretation": (
                            f"Se identificó un patrón compatible "
                            f"con {secret_type} dentro de "
                            f"{section_name}."
                        )
                    })

            if contains_word(
                key,
                SENSITIVE_KEY_WORDS
            ):

                findings.append({
                    "severity":
                        severity_for_credential(
                            key,
                            classification
                        ),

                    "category":
                        "Autenticación / Credenciales",

                    "request":
                        request_name,

                    "field":
                        path,

                    "classification":
                        classification,

                    "value":
                        mask_value(
                            value
                        ),

                    "interpretation":
                        human_credential_text(
                            key,
                            classification
                        )
                })



# ============================================================
# ANALISIS DE NIVEL COLECCION
# ============================================================

collection_name_for_analysis = (
    collection_detail.get("name")
    or alerted_resource.get("collection_name")
    or "Colección alertada"
)

# ------------------------------------------------------------
# VARIABLES DE COLECCION
# ------------------------------------------------------------

collection_variables = (
    collection_detail.get("variables")
    or []
)

if isinstance(collection_variables, list):

    for variable in collection_variables:

        if not isinstance(variable, dict):
            continue

        variable_key = (
            variable.get("key")
            or variable.get("name")
        )

        variable_value = variable.get(
            "value"
        )

        if not variable_key:
            continue

        classification = classify_value(
            variable_value
        )

        field_name = (
            "collection.variables."
            + str(variable_key)
        )

        # Nombre sensible: APIKEY, TOKEN, SECRET, PASSWORD, etc.
        variable_has_value = (
            variable_value is not None
            and str(variable_value).strip() != ""
        )

        if (
            variable_has_value
            and contains_word(
                variable_key,
                SENSITIVE_KEY_WORDS
            )
        ):

            findings.append({
                "severity":
                    severity_for_credential(
                        variable_key,
                        classification
                    ),

                "category":
                    "Autenticación / Credenciales",

                "request":
                    collection_name_for_analysis,

                "field":
                    field_name,

                "classification":
                    classification,

                "value":
                    mask_value(
                        variable_value
                    ),

                "interpretation":
                    (
                        human_credential_text(
                            variable_key,
                            classification
                        )
                        + " El valor se encuentra definido "
                          "a nivel de colección."
                    )
            })

        # Patrones reconocibles aunque el nombre no sea sensible.
        if variable_value:

            for secret_type in detect_secret_patterns(
                variable_value
            ):

                findings.append({
                    "severity": "HIGH",
                    "category":
                        "Autenticación / Credenciales",
                    "request":
                        collection_name_for_analysis,
                    "field":
                        field_name,
                    "classification":
                        "literal_secret_pattern",
                    "value":
                        mask_value(
                            variable_value
                        ),
                    "interpretation":
                        (
                            f"Se identificó un patrón compatible "
                            f"con {secret_type} en una variable "
                            f"de nivel colección."
                        )
                })


# ------------------------------------------------------------
# AUTH DE COLECCION
# ------------------------------------------------------------

collection_auth = (
    collection_detail.get("auth")
)

if collection_auth:

    for entry in walk_values(
        collection_auth
    ):

        key = entry.get(
            "key"
        )

        value = entry.get(
            "value"
        )

        path = (
            "collection.auth."
            + str(
                entry.get("path")
                or key
                or "value"
            )
        )

        classification = classify_value(
            value
        )

        if contains_word(
            key,
            SENSITIVE_KEY_WORDS
        ):

            findings.append({
                "severity":
                    severity_for_credential(
                        key,
                        classification
                    ),

                "category":
                    "Autenticación / Credenciales",

                "request":
                    collection_name_for_analysis,

                "field":
                    path,

                "classification":
                    classification,

                "value":
                    mask_value(
                        value
                    ),

                "interpretation":
                    (
                        human_credential_text(
                            key,
                            classification
                        )
                        + " El valor forma parte de la "
                          "autenticación definida a nivel "
                          "de colección."
                    )
            })

        if value:

            for secret_type in detect_secret_patterns(
                value
            ):

                findings.append({
                    "severity": "HIGH",
                    "category":
                        "Autenticación / Credenciales",
                    "request":
                        collection_name_for_analysis,
                    "field":
                        path,
                    "classification":
                        "literal_secret_pattern",
                    "value":
                        mask_value(
                            value
                        ),
                    "interpretation":
                        (
                            f"Se identificó un patrón compatible "
                            f"con {secret_type} dentro de la "
                            f"autenticación de la colección."
                        )
                })


# ============================================================
# DEDUPLICAR EVIDENCIAS INDIVIDUALES
# ============================================================

deduped = []

seen = set()

for finding in findings:

    signature = (
        finding.get(
            "severity"
        ),
        finding.get(
            "category"
        ),
        finding.get(
            "request"
        ),
        finding.get(
            "field"
        ),
        finding.get(
            "classification"
        ),
        finding.get(
            "value"
        )
    )

    if signature in seen:
        continue

    seen.add(
        signature
    )

    deduped.append(
        finding
    )

findings = deduped


# ============================================================
# AGRUPAR HALLAZGOS
# ============================================================

groups = defaultdict(
    lambda: {
        "severity": None,
        "category": None,
        "field": None,
        "classification": None,
        "value": None,
        "interpretation": None,
        "requests": set(),
        "count": 0
    }
)

severity_order = {
    "HIGH": 4,
    "MEDIUM": 3,
    "LOW": 2,
    "INFO": 1
}


for finding in findings:

    group_key = (
        finding.get(
            "category"
        ),
        finding.get(
            "field"
        ),
        finding.get(
            "classification"
        ),
        finding.get(
            "value"
        )
    )

    group = groups[
        group_key
    ]

    group[
        "count"
    ] += 1

    request_name = (
        finding.get(
            "request"
        )
    )

    if request_name:
        group[
            "requests"
        ].add(
            request_name
        )

    new_severity = (
        finding.get(
            "severity"
        )
    )

    if (
        group[
            "severity"
        ]
        is None
        or severity_order.get(
            new_severity,
            0
        )
        >
        severity_order.get(
            group[
                "severity"
            ],
            0
        )
    ):
        group[
            "severity"
        ] = new_severity

    for key in [
        "category",
        "field",
        "classification",
        "value",
        "interpretation"
    ]:

        if group[
            key
        ] is None:

            group[
                key
            ] = finding.get(
                key
            )


grouped_findings = []

for group in groups.values():

    group[
        "requests"
    ] = sorted(
        group[
            "requests"
        ]
    )

    grouped_findings.append(
        group
    )


grouped_findings.sort(
    key=lambda item: (
        -severity_order.get(
            item.get(
                "severity"
            ),
            0
        ),
        -item.get(
            "count",
            0
        )
    )
)


# ============================================================
# CONTADORES CONSOLIDADOS
# ============================================================

consolidated_counter = Counter(
    finding.get(
        "severity"
    )
    for finding in grouped_findings
)

raw_counter = Counter(
    finding.get(
        "severity"
    )
    for finding in findings
)


def estimate_global_severity(grouped_findings):
    """
    Determina la criticidad global utilizando la clasificación
    estructurada de las evidencias.

    La evidencia de mayor impacto prevalece y no se realiza
    un promedio aritmético.
    """

    if not grouped_findings:
        return "BAJA"

    global_level = "BAJA"

    rank = {
        "BAJA": 1,
        "MEDIA": 2,
        "ALTA": 3,
        "CRÍTICA": 4,
    }

    for finding in grouped_findings:

        severity = str(
            finding.get("severity") or ""
        ).upper()

        classification = str(
            finding.get("classification") or ""
        ).lower()

        field = str(
            finding.get("field") or ""
        ).lower()

        category = str(
            finding.get("category") or ""
        ).lower()

        # Referencias indirectas:
        # no contienen el secreto real.
        if classification in {
            "vault_reference",
            "variable_reference",
        }:
            candidate = "BAJA"

        # Material secreto reconocible directamente expuesto.
        elif classification in {
            "literal_token",
            "literal_secret_pattern",
        }:

            critical_fields = [
                "password",
                "passwd",
                "private_key",
                "private-key",
                "client_secret",
                "client-secret",
            ]

            if any(
                marker in field
                for marker in critical_fields
            ):
                candidate = "CRÍTICA"
            else:
                candidate = "ALTA"

        # Evidencia HIGH generada por el motor.
        elif severity == "HIGH":

            critical_fields = [
                "password",
                "passwd",
                "private_key",
                "private-key",
                "client_secret",
                "client-secret",
            ]

            if any(
                marker in field
                for marker in critical_fields
            ):
                candidate = "CRÍTICA"
            else:
                candidate = "ALTA"

        # Identificadores de autenticación, PII,
        # infraestructura sensible, etc.
        elif severity == "MEDIUM":
            candidate = "MEDIA"

        else:
            candidate = "BAJA"

        if rank[candidate] > rank[global_level]:
            global_level = candidate

    return global_level

def global_severity_summary(
    severity,
    grouped_findings,
    technologies_observed,
    domains,
    environments
):
    """
    Genera una interpretación breve de la criticidad global.
    """

    if severity == "CRÍTICA":
        return (
            "Se identificó exposición directa de material sensible "
            "de alto impacto que podría permitir compromiso o acceso "
            "no autorizado. Requiere validación y mitigación inmediata."
        )

    if severity == "ALTA":
        return (
            "Se identificó información de autenticación o secretos "
            "expuestos directamente que podrían facilitar acceso "
            "no autorizado. Se recomienda validar vigencia y rotar "
            "los valores comprometidos."
        )

    if severity == "MEDIA":
        return (
            "Se identificó información sensible o de autenticación "
            "que requiere validación de vigencia e impacto, además de "
            "información técnica expuesta sobre el servicio."
        )

    if grouped_findings:
        return (
            "Se identificaron referencias de baja sensibilidad o "
            "valores indirectos, sin evidenciarse secretos críticos "
            "expuestos directamente."
        )

    if (
        technologies_observed
        or domains
        or environments
    ):
        return (
            "La publicación expone información técnica sobre "
            "arquitectura, endpoints, entornos o identificadores, "
            "sin evidenciarse credenciales o secretos expuestos "
            "con las reglas actuales."
        )

    return (
        "No se identificaron evidencias relevantes de exposición "
        "sensible con las reglas actuales."
    )

GLOBAL_SEVERITY = estimate_global_severity(
    grouped_findings
)

GLOBAL_SEVERITY_SUMMARY = global_severity_summary(
    GLOBAL_SEVERITY,
    grouped_findings,
    technologies_observed,
    domains,
    environments
)


# ============================================================
# GENERAR ANALYSIS.TXT
# ============================================================

lines = []


def add(text=""):
    lines.append(
        str(text)
    )


def plural(value, singular, plural_form=None):
    try:
        number = int(value)
    except Exception:
        number = value

    if plural_form is None:
        plural_form = singular + "s"

    return singular if number == 1 else plural_form





add(
    "============================================================"
)
add(
    "ANÁLISIS TÉCNICO DE EXPOSICIÓN EN POSTMAN"
)
add(
    "============================================================"
)
add()

add(
    f"Case ID: {case_info.get('case_id')}"
)
add(
    f"Fecha de recolección (Lima): "
    f"{case_info.get('collected_at_lima')}"
)
add(
    f"URL de alerta: "
    f"{case_info.get('alert_url')}"
)
add()


# ------------------------------------------------------------
# PUBLICACION
# ------------------------------------------------------------

add(
    "[PUBLICACIÓN]"
)

add(
    f"Tipo: {ALERT_TYPE.capitalize()}"
)

add(
    f"Workspace: "
    f"{workspace.get('name') or 'No identificado'}"
)

add(
    f"Visibilidad: "
    f"{workspace.get('visibilityStatus') or 'No identificada'}"
)

if ALERT_TYPE == "request":

    add(
        f"Colección: "
        f"{alerted_resource.get('collection_name') or 'No identificada'}"
    )

    add(
        f"Request alertada: "
        f"{alerted_resource.get('request_name') or 'No identificada'}"
    )

    alerted_request_name = (
        alerted_resource.get(
            "request_name"
        )
    )

    alerted_request_dates = None

    for request in request_index:

        if (
            request.get("name")
            == alerted_request_name
        ):
            alerted_request_dates = request
            break

    if alerted_request_dates:

        add(
            f"Creación de la request: "
            f"{format_date_lima(alerted_request_dates.get('createdAt'))}"
        )

        add(
            f"Última actualización de la request: "
            f"{format_date_lima(alerted_request_dates.get('updatedAt'))}"
        )

else:

    add(
        f"Colección alertada: "
        f"{alerted_resource.get('collection_name') or 'No identificada'}"
    )

    add(
        f"Creación de la colección: "
        f"{format_date_lima(collection_detail.get('createdAt'))}"
    )

    add(
        f"Última actualización de la colección: "
        f"{format_date_lima(collection_detail.get('updatedAt'))}"
    )

add(
    f"Creación del workspace: "
    f"{format_date_lima(workspace.get('timeline', {}).get('createdAt'))}"
)

add(
    f"Última actividad: "
    f"{format_date_lima(workspace.get('timeline', {}).get('lastActivityTime'))}"
)

add()


# ------------------------------------------------------------
# ATRIBUCION
# ------------------------------------------------------------

add(
    "[ATRIBUCIÓN]"
)

if not direct_identities:

    add(
        "No se identificó una atribución directa concluyente."
    )

else:

    for identity in direct_identities:

        add(
            f"Perfil: "
            f"{identity.get('name') or 'Sin nombre identificado'}"
        )

        add(
            f"ID Postman: "
            f"{identity.get('user_id') or 'No identificado'}"
        )

        if identity.get(
            "username"
        ):
            add(
                f"Usuario: "
                f"{identity.get('username')}"
            )

        strong_relationships = [
            relationship
            for relationship in (
                identity.get(
                    "relationships"
                )
                or []
            )
            if relationship
            in [
                "workspace_createdBy",
                "workspace_contributor:user",
                "collection_owner",
                "request_owner",
                "alerted_request_owner",
                "alerted_collection_owner"
            ]
        ]

        if len(
            strong_relationships
        ) >= 3:
            confidence = "ALTA"

        elif strong_relationships:
            confidence = "MEDIA"

        else:
            confidence = "BAJA"

        add(
            f"Confianza de atribución: "
            f"{confidence}"
        )

        break


if context_identities:

    visible_context = []

    for identity in context_identities:

        name = (
            identity.get(
                "name"
            )
            or "Private/Unknown User"
        )

        username = (
            identity.get(
                "username"
            )
        )

        if username:
            visible_context.append(
                f"{name} ({username})"
            )
        else:
            visible_context.append(
                name
            )

    if visible_context:
        add(
            "Otros perfiles observados: "
            + ", ".join(
                visible_context[:5]
            )
        )

add()


# ------------------------------------------------------------
# ALCANCE
# ------------------------------------------------------------

collection_count = scope.get(
    "collections",
    0
)

request_count = scope.get(
    "requests",
    0
)

alerted_request_count = scope.get(
    "alerted_collection_requests",
    0
)

add(
    "[ALCANCE]"
)

add(
    f"Workspace: "
    f"{collection_count} "
    f"{plural(collection_count, 'colección', 'colecciones')} / "
    f"{request_count} "
    f"{plural(request_count, 'request')}"
)

add(
    f"Colección analizada: "
    f"{alerted_request_count} "
    f"{plural(alerted_request_count, 'request')}"
)

add()


# ------------------------------------------------------------
# EXPOSICION
# ------------------------------------------------------------

add(
    "[EXPOSICIÓN IDENTIFICADA]"
)


if domains:

    domain_text = ", ".join(
        domain
        for domain in domains.keys()
    )

    add(
        f"Dominio(s): {domain_text}"
    )


if environments:

    environment_text = ", ".join(
        environments.keys()
    )

    add(
        f"Entorno(s): {environment_text}"
    )


if technologies_observed:

    add(
        "Tecnologías: "
        + ", ".join(
            sorted(
                technologies_observed
            )
        )
    )


endpoint_count = len(
    request_index
)

add(
    f"Endpoints/requests analizados: "
    f"{endpoint_count}"
)


if request_index:

    add(
        "Endpoints principales:"
    )

    for request in request_index[:10]:

        url = (
            request.get(
                "url"
            )
            or ""
        )

        parsed = urlparse(
            url
        )

        compact_endpoint = (
            parsed.path
            or url
        )

        if parsed.query:
            compact_endpoint += (
                "?"
                + parsed.query
            )

        add(
            f"- {request.get('method')} "
            f"{compact_endpoint}"
        )

    if len(
        request_index
    ) > 10:

        add(
            f"- ... y "
            f"{len(request_index) - 10} "
            f"requests adicionales"
        )


# ------------------------------------------------------------
# INFORMACION RELEVANTE
# ------------------------------------------------------------

relevant_lines = []


for finding in grouped_findings:

    field = (
        finding.get(
            "field"
        )
        or "Campo no identificado"
    )

    classification = (
        finding.get(
            "classification"
        )
    )

    value = (
        finding.get(
            "value"
        )
    )

    request_count_finding = len(
        finding.get(
            "requests",
            []
        )
    )

    is_collection_level = str(
        field
    ).startswith(
        "collection."
    )

    if is_collection_level:
        scope_suffix = "(nivel colección)."
    else:
        scope_suffix = (
            f"({request_count_finding} "
            f"{plural(request_count_finding, 'request')})."
        )

    if classification == "vault_reference":

        relevant_lines.append(
            f"{field}: referencia a Postman Vault; "
            f"el secreto real no está expuesto "
            f"{scope_suffix}"
        )

    elif classification == "variable_reference":

        relevant_lines.append(
            f"{field}: referencia a variable; "
            f"el valor real no está expuesto directamente "
            f"{scope_suffix}"
        )

    else:

        relevant_lines.append(
            f"{field}: valor visible {value} "
            f"{scope_suffix}"
        )


if technical_headers:

    header_names = sorted(
        technical_headers.keys()
    )

    context_headers = [
        name
        for name in header_names
        if not contains_word(
            name,
            SENSITIVE_KEY_WORDS
        )
    ]

    if context_headers:

        relevant_lines.append(
            "Headers técnicos visibles: "
            + ", ".join(
                context_headers[:8]
            )
            + "."
        )


if query_parameters:

    enabled_params = sorted(
        {
            str(
                item.get(
                    "key"
                )
            )
            for item in query_parameters
            if item.get(
                "enabled",
                True
            )
            and item.get(
                "key"
            )
        }
    )

    disabled_params = sorted(
        {
            str(
                item.get(
                    "key"
                )
            )
            for item in query_parameters
            if item.get(
                "enabled"
            ) is False
            and item.get(
                "key"
            )
        }
    )

    if enabled_params:

        relevant_lines.append(
            "Parámetros visibles: "
            + ", ".join(
                enabled_params[:8]
            )
            + "."
        )

    if disabled_params:

        relevant_lines.append(
            "Parámetros deshabilitados aún visibles: "
            + ", ".join(
                disabled_params[:8]
            )
            + "."
        )


if technical_identifiers:

    identifier_types = sorted(
        {
            str(
                item.get(
                    "type"
                )
            )
            for item in technical_identifiers
            if item.get(
                "type"
            )
        }
    )

    if identifier_types:

        relevant_lines.append(
            "Identificadores técnicos visibles: "
            + ", ".join(
                identifier_types
            )
            + "."
        )


related_emails = (
    identity_raw.get(
        "emails_from_related_evidence"
    )
    or []
)


if related_emails:

    relevant_lines.append(
        f"Correos identificados: "
        f"{len(related_emails)}."
    )


if relevant_lines:

    add(
        "Información relevante:"
    )

    # Mostrar todos los hallazgos relevantes consolidados.
    # No se aplica un límite fijo; la síntesis se obtiene
    # mediante agrupación y deduplicación previa.

    seen_relevant_lines = set()

    for line in relevant_lines:

        normalized_line = str(line).strip()

        if not normalized_line:
            continue

        if normalized_line in seen_relevant_lines:
            continue

        seen_relevant_lines.add(
            normalized_line
        )

        add(
            f"- {normalized_line}"
        )

else:

    add(
        "No se identificaron credenciales, secretos o "
        "información sensible adicional con las reglas actuales."
    )

add()


# ------------------------------------------------------------
# CRITICIDAD GLOBAL
# ------------------------------------------------------------

add(
    "[CRITICIDAD ESTIMADA]"
)

add(
    GLOBAL_SEVERITY
)

add(
    GLOBAL_SEVERITY_SUMMARY
)

add()


# ------------------------------------------------------------
# NOTAS
# ------------------------------------------------------------

add(
    "[NOTAS]"
)

add(
    "- Las fechas corresponden a metadata de Postman y no "
    "representan necesariamente la fecha exacta de publicación."
)

add(
    "- Los valores potencialmente sensibles se muestran "
    "ofuscados en este resumen; la evidencia completa se "
    "conserva en los archivos JSON del caso."
)

add(
    "- El análisis no ejecuta los endpoints ni valida "
    "credenciales contra los servicios identificados."
)

add()


# ============================================================
# GUARDAR
# ============================================================

with open(
    OUTPUT_FILE,
    "w",
    encoding="utf-8"
) as file:

    file.write(
        "\n".join(
            lines
        )
    )


# ============================================================
# RESULTADO
# ============================================================

print()
print(
    "========================================"
)
print(
    "ANALISIS COMPLETADO"
)
print(
    "========================================"
)

print(
    "[+] Case ID:",
    case_info.get(
        "case_id"
    )
)

print(
    "[+] Workspace:",
    workspace.get(
        "name"
    )
)

print(
    "[+] Requests analizadas:",
    len(
        requests
    )
)

print(
    "[+] Hallazgos consolidados:",
    len(
        grouped_findings
    )
)

print(
    "[+] Criticidad estimada:",
    GLOBAL_SEVERITY
)

print(
    "[+] Evidencias individuales:",
    len(
        findings
    )
)

print(
    "[+] Archivo:",
    OUTPUT_FILE
)
